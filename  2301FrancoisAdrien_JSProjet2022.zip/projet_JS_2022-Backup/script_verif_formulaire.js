
	$(document).ready(function(){ 
	$('form').validate({
			rules : {
	      nom : {
	        required : true,
	        minlength : 3
	      },
	      prenom : {
	        required : true
	      },
	      email : {
	        required : true,
	        email : true
	      },
	      telephone : {
	        required: true,
	        number: true
	      },
	      pseudo : {
	        required : true	     
	      },
	      mpd : {
	      	pwcheck: true,
	      	required: true,
	      	minlength: 8
	      },
	    },
	    messages : {
	      prenom : "Veuillez fournir un prénom",
	      nom : "Veuillez fournir un nom d'au moins trois lettres",
	      email : "L'email est mal formé",
	      telephone : "Le numéro de téléphone doit uniquement contenir des chiffres",
	      pseudo : "Veuillez fournir un pseudo",
	      mpd : "Veuillez entrez un pseudo au format valide"
	    },
	    submitHandler: function(form) {

	     	var nom = $('#nom').val();
			var prenom = $('#prenom').val();
			var email = $('#email').val();
			var telephone = $('#telephone').val();
			var pseudo = $('#pseudo').val();
			var mdp = $('#mdp').val();
			var etat = $('#etat').val();

			console

			alert('test');

			$.ajax({

				type:"post",
				url:"inscription_utilisateur_bd_ajax.php",
				data:"nom="+nom + "&prenom="+prenom + "&email="+email + "&telephone="+telephone + "&pseudo="+pseudo + "&mdp="+mdp+ "&etat="+etat,
				success : function(data){
					sessionStorage.setItem('id_utilisateur',data);					 
					document.location.href = "accueil.php";
				}		
			})
	      //"Appel d'une fonction qui va lancer la soumission du formulaire en ajax"
	    },
	    invalidHandler: function(form){
	      //"Appel d'une fonction qui va apporter de l'aide à l'utilisateur"
	      console.log('PAS BON ');
	    }
	  });
	  $.validator.addMethod("pwcheck", function(value) {
	   return /^[A-Za-z0-9\d=!\-@._*]*$/.test(value) // consists of only these
	       && /[a-z]/.test(value) // has a lowercase letter
	       && /\d/.test(value) // has a digit
		});

});