<!DOCTYPE html>
<html>
<head>
	<title>Modifier champs formulaire</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="projetjs.css">
	<link href="froala_editor_4.0.13/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
	
	<script type="text/javascript" src="jquery-3.6.0.min.js"></script>
	<script type="text/javascript" src ="script.js"></script>
	<script src="/path/to//js/form-to-json.js"></script>

	<?php  
		if(isset($_GET['id']))
		{
			$idformulaire = $_GET['id'];
		}
	?>
	<script type="text/javascript">
	
	$(document).ready(function () {

			var json_reponse;

			$.ajax({
				type:"post",
				url:"retrieve_code_titre_formulaire_bd.php",
				data:"id=" + <?php  print $idformulaire; ?>,				
				success : function(data){
						//alert(data);				 
					$('#alert').html(data);
				}		
			});

			$.ajax({
				type:"post",
				url:"retrieve_champs_formulaire_reponse_bd.php",
				data:"id=" + <?php  print $idformulaire; ?> + "&idrepondant="+sessionStorage.getItem('id_utilisateur'),
				success : function(data){
						//alert(data);				 
					$('#formulaire_principal_reponse').html(data);
				}		
			});

			    $('#formulaire_principal_reponse').on('click','#sauvegarder_json',function(){
		    	
			    	json_reponse= '{';	

			    	$('#formulaire_principal_reponse input[type="text"]').each(function(index){	
			    		var name_champ = $(this).attr('name');    		
						var	reponse_text = $(this).val();
						var reponse_champ = '"'+name_champ+'": "'+reponse_text+'"';

						json_reponse+=reponse_champ;

						json_reponse+=',';
/*
						if(index == $('#formulaire_principal_reponse input[type="text"]').length -1) 
			    		{	
			    			json_reponse+='';
						  	    				
		    			}else
		    			{
		    				json_reponse+=',';
		    			}	*/
			    	});

			    	$('#formulaire_principal_reponse select').each(function(index){

			    		var name_champ = $(this).attr('name');
			    		var reponse_select= $('option:selected', this).html();
			    		json_reponse+= '"'+name_champ+'": "'+reponse_select+'"';

			    		json_reponse+=',';
			    	/*	if(index == $('#formulaire_principal_reponse select').length -1) 
			    		{	
			    			json_reponse+='';
						  	    				
		    			}else
		    			{
		    				json_reponse+=',';
		    			}	*/
			    	});

			    	$('#formulaire_principal_reponse .groupe_champ_check').each(function(index){

			    		var name_champ = $(this).html();
			    		json_reponse+= '"'+name_champ+'": "';

			    		var length= $('input[type="checkbox"]:checked').length;	

			    		$('input[type="checkbox"]:checked').each(function(index){
			    			var option_champ = $(this).attr('name');  
			    			json_reponse+= option_champ;
	 
				    		if(index == length -1) 
				    		{	
				    			json_reponse+='';
							  	    				
			    			}else
			    			{
			    				json_reponse+=',';
			    			}	
			    			
			    		});

			    	/*	if(index == $('#formulaire_principal_reponse #label_champ_check').length -1) 
			    		{	
			    			json_reponse+=']';
						  	    				
		    			}else
		    			{
		    				json_reponse+='],';
		    			}	*/
		    			json_reponse+='",';
			    	});

			    	$('#formulaire_principal_reponse .groupe_champ_radio').each(function(index){

			    		var name_champ = $('#label_champ_radio',this).html();
			    		var reponse_radio= $('input[type="radio"]:checked', this).val(); 
			    		
			    		json_reponse+='"'+name_champ+'": "'+reponse_radio+'"';

			    		if(index == $('#formulaire_principal_reponse .groupe_champ_radio').length -1) 
			    		{	
			    			json_reponse+='';
						  	    				
		    			}else
		    			{
		    				json_reponse+=',';
		    			}	
			    	});

			    	json_reponse+='}';
		

			    	console.log('reponse : ', json_reponse);
			    	console.log('reponse json : ', JSON.stringify(json_reponse));
			    	
				return false; 
				});

				$('#btn_sauvegarder_formulaire').click(function(){


					$.ajax({
						type:"post",
						url:"sauvegarder_reponse_bd_ajax.php",
						data:"json_reponse="+ json_reponse + "&idformulaire="+ <?php  print $idformulaire; ?> + "&idutilisateur="+sessionStorage.getItem('id_utilisateur'),						
						success : function(data){	
						//alert(data);			 									
						}		
					});
					
				});
	   //  });	
	});

</script>
</head>
<body>
	<nav class="navbar navbar-expand-xxl navbar-dark bg-primary">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="accueil.php">Projet Javascript 2022</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarNav">
	      <ul class="navbar-nav">
	        <li class="nav-item">
	          <a class="nav-link" aria-current="page" href="accueil.php">Édition formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="lecteur_formulaire.php">Lecture formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link active" href="">Réponse formulaire</a>
	        </li>
	      </ul>
	    </div>
	        <ul class="navbar-nav ml-auto" id="navbarNav">
		        <li class="nav-item">
		          <a class="nav-link" href="deconnexion_utilisateur.php">Déconnexion</a>
		        </li>
	        </ul>
	  </div>
	</nav>

	<br/>
		<a class="btn btn-primary" href="repondant_formulaire.php" role="button" >Listes des formulaires </a>
	<br/>
	<br/>
		<h1>Répondre au formulaire</h1>
	<br/>

	<div id="alert" class="alert alert-primary" role="alert">
  		
	</div>

	<div class="container">
  		<div class="row">
    		<div class="col-lg-12">
      			<form id="formulaire_principal_reponse"></form>
   			</div>
   		</div>
   	
	</div>

	<div class="modal fade" id="modal_sauvegarder_formulaire" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Sauvegarder un formulaire </h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	     	<form method="post">
	      		<div class="modal-body">       
					 <p> Êtes vous sûr de vouloir sauvegarder le formulaire n°<?php echo $idformulaire; ?> ?</p>
				  <div class="modal-footer">
			        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
			        <button type="submit" id="btn_sauvegarder_formulaire" href="repondant_formulaire_.php" class="btn btn-success">Sauvegarder</button>
			      </div>
			
	      		</div>
	      </form>
	    </div>
	  </div>
	</div>



	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" ></script>

</body>
</html>