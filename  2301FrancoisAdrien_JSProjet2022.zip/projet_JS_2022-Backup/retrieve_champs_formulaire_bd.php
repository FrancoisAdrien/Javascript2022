<?php

      include('connexion_bd.php');

      	if(isset($_POST['id']))
      	{
      		$idformulaire=$_POST['id'];
      	}

      $champ_bd = $connexion_bd_projetjs->query('SELECT * FROM champ WHERE idformulaire = \'' . $idformulaire . '\' '); // where id = valeur de l'utilisateur

      $liste_champs = $champ_bd->fetchALL();

	?>

      <?php 
      foreach($liste_champs as $champ)
	  	{  	 
		  	?>	
		  	<?php 
		  		if($champ['type'] == 'champ_courte'){
		  	?>	   
			     <div class="mb-3">
					<label for="exampleFormControlTextarea1" id="label_champ_courte"class="form-label"><?php echo $champ['titre_champ'];?>
					</label>
					<a class="icone" data-bs-toggle="modal" data-bs-target="#modal_supprimer_champ_formulaire" data-id="<?php echo $champ['id'];?>"><i class="fa fa-trash"></i></a>
					<input type ="text" class="form-control" id="<?php echo $champ['titre_champ'];?>" name="<?php echo $champ['titre_champ'];?>" placeholder="<?php echo $champ['description_champ'];?>">
					
				</div>

			<?php 
		  		}
		  		else if($champ['type'] == 'champ_longue'){
		  	?>

		  		 <div class="mb-3">
					<label for="exampleFormControlTextarea1" id="label_champ_longue"class="form-label"><?php echo $champ['titre_champ'];?>
					</label>
					<a class="icone" href="supprimer_formulaire_bd.php?id=<?php echo $champ['id'] ?>"><i class="fa fa-trash"></i></a>
					<textarea type ="text" class="form-control" id="<?php echo $champ['titre_champ'];?>" name="<?php echo $champ['titre_champ'];?>" placeholder="<?php echo $champ['description_champ'];?>"> </textarea>
					
				</div>

	  		<?php 
		  		}
		  		else if($champ['type'] == 'champ_select'){
		  	?>
		  		<div class="mb-3">
			  		<label for="formGroupExampleInput" id="label_champ_select"class="form-label"><?php echo $champ['titre_champ'];?> </label>
			  		<a class="icone" href="supprimer_formulaire_bd.php?id=<?php echo $champ['id'] ?>"><i class="fa fa-trash"></i></a>
			  		<div class="mb-3">
			  			<select class="form-select" aria-label="Default select example" id="form_select">
				
			  		<?php
			  			$idchamp=$champ['id'];
			  			$option_champ_bd = $connexion_bd_projetjs->query('SELECT * FROM option_champ WHERE idchamp = \'' . $idchamp . '\' '); 
	      				$liste_options = $option_champ_bd->fetchALL();

	      				 foreach($liste_options as $option)
	      				 {
	      			?> 				
	      				<option value="1" id="option_nouveau_select"><?php echo $option['titre_option'];?></option>

	      			<?php	  
	      				 }		
      				?>
      					</select>
      					
      				</div>
			  	</div>

		  	<?php
		  		}
		  		else if($champ['type'] == 'champ_check'){	  						
		  	?>
		  		<div class="mb-3">
			  		<label for="formGroupExampleInput" id="label_champ_check"class="form-label"><?php echo $champ['titre_champ'];?> </label>
			  		<a class="icone" href="supprimer_formulaire_bd.php?id=<?php echo $champ['id'] ?>"><i class="fa fa-trash"></i></a>
			  		<div class="mb-3">
			  		<?php
			  			$idchamp=$champ['id'];
			  			$option_champ_bd = $connexion_bd_projetjs->query('SELECT * FROM option_champ WHERE idchamp = \'' . $idchamp . '\' '); 
	      				$liste_options = $option_champ_bd->fetchALL();

	      				 foreach($liste_options as $option)
	      				 {
	      			?> 				
	      				<input class="form-check-input" type="checkbox" value="" name="<?php echo $option['titre_option'];?>" id="<?php echo $option['titre_option'];?>">
						<label class="form-check-label" for="flexCheckDefault"id="nouveau_label_check"><?php echo $option['titre_option'];?></label>
						

	      			<?php	  
	      				 }		
      				?>
      				</div>
			  	</div>
		  	
		  	<?php 
		  		}
		  		else if($champ['type'] == 'champ_radio'){
		  	?>
		  		<div class="mb-3">
			  		<label for="formGroupExampleInput" id="label_champ_radio"class="form-label"><?php echo $champ['titre_champ'];?> </label>
			  		<a class="icone" href="supprimer_formulaire_bd.php?id=<?php echo $champ['id'] ?>"><i class="fa fa-trash"></i></a>
			  		<div class="mb-3">

			  		<?php
			  			$idchamp=$champ['id'];
			  			$option_champ_bd = $connexion_bd_projetjs->query('SELECT * FROM option_champ WHERE idchamp = \'' . $idchamp . '\' '); 
	      				$liste_options = $option_champ_bd->fetchALL();

	      				 foreach($liste_options as $option)
	      				 {
	      			?> 				
	      				<input class="form-check-input" type="radio" value="<?php echo $option['titre_option'];?>" name="radioDefault" id="<?php echo $option['titre_option'];?>">
  						<label class="form-check-label" for="flexRadioDefault1" id="nouveau_label_radio"><?php echo $option['titre_option'];?></label>
  						

	      			<?php	  
	      				 }		
      				?>
      				</div>
			  	</div>
		  	<?php 
		  		}
		  	?>

		<?php    
		} 
		?>
 

   