<!DOCTYPE html>
<html>
<head>
	<title>Inscription utilisateur</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="projetjs.css">
	<link href="froala_editor_4.0.13/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
	
	<script type="text/javascript" src="jquery-3.6.0.min.js"></script>
	<script type="text/javascript" src="script_verif_formulaire.js"></script> 
	<script type="text/javascript" src="jquery.validate.min.js"></script>
	<script type="text/javascript" src="additional-methods.min.js"></script>
	
	<script type="text/javascript">
	
	$(document).ready(function () {

	/*	$('form').submit(function(){
			var nom = $('#nom').val();
			var prenom = $('#prenom').val();
			var email = $('#email').val();
			var telephone = $('#telephone').val();
			var pseudo = $('#pseudo').val();
			var mdp = $('#mdp').val();
			var etat = $('#etat').val();

			alert('test');

			$.ajax({

				type:"post",
				url:"inscription_utilisateur_bd_ajax.php",
				data:"nom="+nom + "&prenom="+prenom + "&email="+email + "&telephone="+telephone + "&pseudo="+pseudo + "&mdp="+mdp+ "&etat="+etat,
				success : function(data){
					sessionStorage.setItem('id_utilisateur',data);					 
					document.location.href = "accueil.php";
				}		
			});
			return false; 
		});*/

	});
</script>

</head>

<body>
	<nav class="navbar navbar-expand-xxl navbar-dark bg-primary">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="accueil.php">Projet Javascript 2022</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarNav">
	      <ul class="navbar-nav">
	   <!--     <li class="nav-item">
	          <a class="nav-link active"  href="#">Édition formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Lecture formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Réponse formulaire</a>
	        </li>-->
	        <li class="nav-item">
          		<a class="nav-link"  aria-current="page" href="connexion_utilisateur.php">Connexion</a>
       		</li>
	      </ul>
	    </div>
	  </div>
	</nav>
	<form method="post">
		  <div class="mb-3">
		    <label for="nom" class="form-label">Nom</label>
		    <input type="text" class="form-control" id="nom" name="nom" >
		  </div>
		   <div class="mb-3">
		    <label for="prenom" class="form-label">Prenom</label>
		    <input type="text" class="form-control" id="prenom" name="prenom" >
		  </div>
		   <div class="mb-3">
		    <label for="email" class="form-label">Email</label>
		    <input type="email" class="form-control" id="email" name="email">
		  </div>
		   <div class="mb-3">
		    <label for="telephone" class="form-label">Telephone</label>
		    <input type="text" class="form-control" id="telephone" name="telephone">
		  </div>
		   <div class="mb-3">
		    <label for="pseudo" class="form-label">Pseudo</label>
		    <input type="text" class="form-control" id="pseudo" name="pseudo">
		  </div>
		   <div class="mb-3">
		    <label for="mdp" class="form-label">Mdp</label>
		    <input type="password" class="form-control" id="mdp" name="mdp">
		  </div>
		   <div class="mb-3">
		    <label for="etat" class="form-label">Etat</label>
		    <input type="text" class="form-control" id="etat" name="etat">
		  </div>
		  <button type="submit" class="btn btn-success">S'inscrire</button>
		  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
		</form>
</body>
</html>