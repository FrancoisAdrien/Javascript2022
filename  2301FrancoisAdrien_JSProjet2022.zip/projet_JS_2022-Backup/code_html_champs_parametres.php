
<!-- MODAL REPONSE COURTE  -->
	<div class="modal fade" id="modal_reponse_courte" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Réponse courte</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">

	       	<form>
			  <div class="mb-3">
			    <label for="titre_champ_courte" class="form-label">Titre du champ</label>
			    <input type="text" class="form-control" id="titre_champ_courte" >
			  </div>
			  <div class="mb-3">
			    <label for="description_champ_courte" class="form-label">Description du champ</label>
			    <input type="text" class="form-control" id="description_champ_courte" >
			  </div>
			  <div class="mb-3 form-check">
			    <input type="checkbox" class="form-check-input" id="check_champ_courte">
			    <label class="form-check-label" for="check_champ_courte">Champ obligatoire</label>
			  </div>
			  <button type="submit" class="btn btn-success" id="courte">Ajouter le champ</button>
			  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
			</form>

	      </div>
	    </div>
	  </div>
	</div>

	<!-- MODAL REPONSE LONGUE  -->
	<div class="modal fade" id="modal_reponse_longue" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Réponse longue</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">

	       	<form>
			  <div class="mb-3">
			    <label for="titre_champ_longue" class="form-label">Titre du champ</label>
			    <input type="text" class="form-control" id="titre_champ_longue" >
			  </div>
			  <div class="mb-3">
			    <label for="description_champ_longue" class="form-label">Description du champ</label>
			    <input type="text" class="form-control" id="description_champ_longue" >
			  </div>
			  <div class="mb-3 form-check">
			    <input type="checkbox" class="form-check-input" id="check_champ_longue">
			    <label class="form-check-label" for="check_champ_longue">Champ obligatoire</label>
			  </div>
			  <button type="submit" class="btn btn-success" id="longue">Ajouter le champ</button>
			  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
			</form>

	      </div>
	    </div>
	  </div>
	</div>

	<!-- MODAL REPONSE CHECKBOX  -->

	<div class="modal fade" id="modal_reponse_check" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Réponse Checkbox</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	       <form id="form_check">	
				  <div class="mb-3">
				    <label for="titre_champ_check" class="form-label">Titre du champ</label>
				    <input type="text" class="form-control" id="titre_champ_check" >
				  </div>
				  <div id="prepend_form">
					    <div class="new_check">
						  <div class="mb-3">
						  	<label for="new_option_check" class="form-label">Réponse</label>
						    <input type="text" class="form-control" id="new_option_check" >
						  </div>
						</div>
					</div>
			  <button type="submit" class="btn btn-success" id="check">Ajouter </button>
			  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
			  <button type="button" id="addCheck" class="btn btn-info">+ Nouvelles options</button>			 
			</form>
 				 
	      </div>
	    </div>
	  </div>
	</div>

	<!-- MODAL REPONSE SELECT  -->

	<div class="modal fade" id="modal_reponse_select" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Réponse de Sélection</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	       <form id="form_select">	
				  <div class="mb-3">
				    <label for="titre_champ_select" class="form-label">Titre du champ</label>
				    <input type="text" class="form-control" id="titre_champ_select" >
				  </div>
				  <div id="prepend_form_select">
					    <div class="new_select">
						  <div class="mb-3">
						  	<label for="new_option_select" class="form-label">Réponse</label>
						    <input type="text" class="form-control" id="new_option_select" >
						  </div>
						</div>
					</div>
			  <button type="submit" class="btn btn-success" id="select">Ajouter </button>
			  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
			  <button type="button" id="addSelect" class="btn btn-info">+ Nouvelles options</button>			 
			</form>
 				 
	      </div>
	    </div>
	  </div>
	</div>

	<!-- MODAL REPONSE RADIO  -->

	<div class="modal fade" id="modal_reponse_radio" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Réponse Radio</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	       <form id="form_radio">	
				  <div class="mb-3">
				    <label for="titre_champ_radio_test" class="form-label">Titre du champ</label>
				    <input type="text" class="form-control" id="titre_champ_radio_test" >
				  </div>
				  <div id="prepend_form_radio">
					    <div class="new_radio">
						  <div class="mb-3">
						  	<label for="new_option_radio" class="form-label">Réponse</label>
						    <input type="text" class="form-control" id="new_option_radio" >
						  </div>
						</div>
					</div>
			  <button type="submit" class="btn btn-success" id="radio">Ajouter </button>
			  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
			  <button type="button" id="addRadio" class="btn btn-info">+ Nouvelles options</button>			 
			</form>
 				 
	      </div>
	    </div>
	  </div>
	</div>

	<!-- paramétrage des champs à ajouter au formulaire principal  -->

	<div hidden = "true">
		<div id="champ_courte">
			<div class="mb-3">
				<label for="exampleFormControlTextarea1" id="label_champ_courte"class="form-label">Veuillez entrer votre question
				</label>
				<input type ="text" class="form-control" id="input_champ_courte">
			</div>
		</div>		
	</div>

	<!-- champ de réponses longue  -->
	<div hidden = "true">
		<div id="champ_longue">
			<div class="mb-3">
				<label for="exampleFormControlTextarea1" id="label_champ_longue"class="form-label">Veuillez entrer votre question
				</label>
				<textarea id="input_champ_longue" name="input_champ_longue"> </textarea>
			</div>
		</div>		
	</div>
	<!-- CHECK Champ Checkbox avec label de titre pour le formulaire principal  -->
	<div hidden = "true">
		<div id="champ_check">
			<div class="row">		
				<label for="formGroupExampleInput" id="label_champ_check"class="form-label">Entrez votre question </label>
				<div id="champ_check_unique">
				<!--	<div class="form-check " >
						<input class="form-check-input" type="checkbox" name="" value="" id="input_check">
						<label class="form-check-label" for="flexCheckDefault"id="label_check">Checkbox numero 1</label>
					</div> -->
				</div>		
			</div>
		</div>
	</div>
	<!-- CHECK Nouveau champ check pour le formulaire principal  -->
	<div hidden = "true">
		<div id="new_champ_check_formulaire_principal">
			<div id="form_check_base" class="form_check_base">		 
			  	<input class="form-check-input" type="checkbox" value="" name="" id="input_nouveau_check">
				<label class="form-check-label" for="flexCheckDefault"id="nouveau_label_check">Checkbox numero 1</label>
			</div>
		</div>
	</div>
	<!-- CHECK Nouveau champ check pour la boite de dialogue  -->
	<div hidden = "true">
		<div id="new_champ_check_modal">
			<div class="new_check">
				<div class="mb-3">
				  	<label for="new_option_check" class="form-label">Réponse</label>
				    <input type="text" class="form-control" id="new_option_check" >
			 	 </div>
			</div>		 
		</div>
	</div>
	
	<!-- SELECT Champ Select avec label de titre pour le formulaire principal  -->

	<div hidden = "true">
		<div id="champ_select">		
			<label for="formGroupExampleInput" id="label_champ_select"class="form-label">Entrez votre question </label>	
				<select class="form-select" aria-label="Default select example" id="form_select">
				</select>				
		</div>
	</div> 

	<!-- SELECT  Nouveau champ select pour le formulaire principal  -->

	<div hidden = "true">
		<div id="new_champ_select_formulaire_principal">		 
			  <option value="1" id="option_nouveau_select">Option 1</option> <!--  COMMENT CHANGER "OPTION 1" ?? -->
		</div>
	</div>

	<!-- SELECT Nouveau champ select pour la boite de dialogue  -->
	<div hidden = "true">
		<div id="new_champ_select_modal">
			<div class="new_select">
				<div class="mb-3">
				  	<label for="new_option_select" class="form-label">Réponse</label>
				    <input type="text" class="form-control" id="new_option_select" >
			 	 </div>
			</div>		 
		</div>
	</div>

	<!-- RADIO Champ Radio avec label de titre pour le formulaire principal  -->
	<div hidden = "true">
		<div id="champ_radio">
			<div class="mb-3">		
				<label for="formGroupExampleInput" id="label_champ_radio"class="form-label">Entrez votre question </label>
				<div id="champ_radio_unique">
				
				</div>		
			</div>
		</div>
	</div>
	<!-- RADIO Nouveau champ radio pour le formulaire principal  -->
	<div hidden = "true">
		<div id="new_champ_radio_formulaire_principal">
			<div id="form_radio_base" class="form_radio_base">		 
				<input class="form-check-input" type="radio" name="" id="input_nouveau_radio">
  				<label class="form-check-label" for="flexRadioDefault1" id="nouveau_label_radio"> Default radio </label>
			</div>
		</div>
	</div>
	<!-- RADIO Nouveau champ radio pour la boite de dialogue  -->
	<div hidden = "true">
		<div id="new_champ_radio_modal">
			<div class="new_radio">
				<div class="mb-3">
				  	<label for="new_option_radio" class="form-label">Réponse</label>
				    <input type="text" class="form-control" id="new_option_radio" >
			 	 </div>
			</div>		 
		</div>
	</div>