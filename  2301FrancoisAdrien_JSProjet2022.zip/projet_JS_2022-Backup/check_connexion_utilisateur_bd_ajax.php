<?php

	include('connexion_bd.php');

	if(isset($_POST['pseudo']) && isset($_POST['mdp']))
	{	
		$pseudo = $_POST['pseudo'];
		$mdp = $_POST['mdp'];


		$requete = $connexion_bd_projetjs->query("SELECT id FROM utilisateur WHERE pseudo = '".$pseudo."' AND mdp= '".$mdp."'");
		$id_utilisateur = $requete->fetch();

		echo $id_utilisateur['id'];		
	}	
?>