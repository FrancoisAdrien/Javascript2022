<?php
	session_start();	
	if (isset($_SESSION['pseudo']))
	{
	}
	else
		$_SESSION['pseudo']=(isset($_POST['pseudo']))?$_POST['pseudo']:null;
?>

<!DOCTYPE html>
<html>
<head>
	<title>Formuliare dynamique</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="produits.css">
	<link href="froala_editor_4.0.13/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
	
	<script type="text/javascript" src="jquery-3.6.0.min.js"></script> 

	<script type="text/javascript" src ="script.js">	

	</script>


</head>
<body>
	
<div>
	<h1 id="entete">Formulaire dynamique <script type="text/javascript"> document.write(sessionStorage.getItem('pseudo_utilisateur')); </script></h1>
		<a href="inscription_utilisateur.php">Inscription</a>
		<button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#" >Radio</button>
</div>
	

	<!--  DEBUT FORMULAIRE PRINCIPAL  -->
<ul class="nav nav-pills nav-justified">
  <li class="nav-item">
    <a class="nav-link active" aria-current="page" href="#">Création de formulaire</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Lecture de formulaire</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#">Réponse de formulaire</a>
  </li>
  
</ul>

<div class="container text-center">
  <div class="row">
    <div class="col-lg">
     <!--<button type="button" class="btn btn-success">Connexion</button> -->
    </div>
    <div class="col-lg">
      <form id="formulaire_principal">			
		</form>
		<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal_reponse_courte">Réponse courte</button>
		<button type="button" id="longue" class="btn btn-warning">Réponse longue</button>
		<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_reponse_select">Liste</button>
		<button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#modal_reponse_check" >Check</button>
		<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal_reponse_radio" >Radio</button>
    </div>
    <div class="col-lg">
      
    </div>
  </div>
</div>
	

	<!--  FIN FORMULAIRE PRINCIPAL  -->

	<!-- MODAL REPONSE COURTE  -->
	<div class="modal fade" id="modal_reponse_courte" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Réponse courte</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">

	       	<form>
			  <div class="mb-3">
			    <label for="titre_champ_courte" class="form-label">Titre du champ</label>
			    <input type="text" class="form-control" id="titre_champ_courte" >
			  </div>
			  <div class="mb-3">
			    <label for="description_champ_courte" class="form-label">Description du champ</label>
			    <input type="text" class="form-control" id="description_champ_courte" >
			  </div>
			  <div class="mb-3 form-check">
			    <input type="checkbox" class="form-check-input" id="check_champ_courte">
			    <label class="form-check-label" for="check_champ_courte">Champ obligatoire</label>
			  </div>
			  <button type="submit" class="btn btn-success" id="courte">Ajouter le champ</button>
			  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
			</form>

	      </div>
	    </div>
	  </div>
	</div>

	<!-- MODAL REPONSE CHECKBOX  -->

	<div class="modal fade" id="modal_reponse_check" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Réponse Checkbox</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	       <form id="form_check">	
				  <div class="mb-3">
				    <label for="titre_champ_check" class="form-label">Titre du champ</label>
				    <input type="text" class="form-control" id="titre_champ_check" >
				  </div>
				  <div id="prepend_form">
					    <div class="new_check">
						  <div class="mb-3">
						  	<label for="new_option_check" class="form-label">Réponse</label>
						    <input type="text" class="form-control" id="new_option_check" >
						  </div>
						</div>
					</div>
			  <button type="submit" class="btn btn-success" id="check">Ajouter </button>
			  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
			  <button type="button" id="addCheck" class="btn btn-info">+ Nouvelles options</button>			 
			</form>
 				 
	      </div>
	    </div>
	  </div>
	</div>

	<!-- MODAL REPONSE SELECT  -->

	<div class="modal fade" id="modal_reponse_select" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Réponse de Sélection</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	       <form id="form_select">	
				  <div class="mb-3">
				    <label for="titre_champ_select" class="form-label">Titre du champ</label>
				    <input type="text" class="form-control" id="titre_champ_select" >
				  </div>
				  <div id="prepend_form_select">
					    <div class="new_select">
						  <div class="mb-3">
						  	<label for="new_option_select" class="form-label">Réponse</label>
						    <input type="text" class="form-control" id="new_option_select" >
						  </div>
						</div>
					</div>
			  <button type="submit" class="btn btn-success" id="select">Ajouter </button>
			  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
			  <button type="button" id="addSelect" class="btn btn-info">+ Nouvelles options</button>			 
			</form>
 				 
	      </div>
	    </div>
	  </div>
	</div>

	<!-- MODAL REPONSE RADIO  -->

	<div class="modal fade" id="modal_reponse_radio" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog modal-dialog-centered">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Réponse Radio</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	       <form id="form_radio">	
				  <div class="mb-3">
				    <label for="titre_champ_radio" class="form-label">Titre du champ</label>
				    <input type="text" class="form-control" id="titre_champ_radio" >
				  </div>
				  <div id="prepend_form_radio">
					    <div class="new_radio">
						  <div class="mb-3">
						  	<label for="new_option_radio" class="form-label">Réponse</label>
						    <input type="text" class="form-control" id="new_option_radio" >
						  </div>
						</div>
					</div>
			  <button type="submit" class="btn btn-success" id="radio">Ajouter </button>
			  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
			  <button type="button" id="addRadio" class="btn btn-info">+ Nouvelles options</button>			 
			</form>
 				 
	      </div>
	    </div>
	  </div>
	</div>

	<!-- paramétrage des champs à ajouter au formulaire principal  -->

	<div hidden = "true">
		<div id="champ_courte">
			<div class="mb-3">
				<label for="exampleFormControlTextarea1" id="label_champ_courte"class="form-label">Veuillez entrer votre question
				</label>
				<input type ="text" class="form-control" id="input_champ_courte">
			</div>
		</div>		
	</div>
	<!-- CHECK Champ Checkbox avec label de titre pour le formulaire principal  -->
	<div hidden = "true">
		<div id="champ_check">
			<div class="row">		
				<label for="formGroupExampleInput" id="label_champ_check"class="form-label">Entrez votre question </label>
				<div id="champ_check_unique">
				<!--	<div class="form-check " >
						<input class="form-check-input" type="checkbox" name="" value="" id="input_check">
						<label class="form-check-label" for="flexCheckDefault"id="label_check">Checkbox numero 1</label>
					</div> -->
				</div>		
			</div>
		</div>
	</div>
	<!-- CHECK Nouveau champ check pour le formulaire principal  -->
	<div hidden = "true">
		<div id="new_champ_check_formulaire_principal">
			<div id="form_check_base" class="form_check_base">		 
			  	<input class="form-check-input" type="checkbox" value="" name="" id="input_nouveau_check">
				<label class="form-check-label" for="flexCheckDefault"id="nouveau_label_check">Checkbox numero 1</label>
			</div>
		</div>
	</div>
	<!-- CHECK Nouveau champ check pour la boite de dialogue  -->
	<div hidden = "true">
		<div id="new_champ_check_modal">
			<div class="new_check">
				<div class="mb-3">
				  	<label for="new_option_check" class="form-label">Réponse</label>
				    <input type="text" class="form-control" id="new_option_check" >
			 	 </div>
			</div>		 
		</div>
	</div>
	
	<!-- SELECT Champ Select avec label de titre pour le formulaire principal  -->

	<div hidden = "true">
		<div id="champ_select">		
			<label for="formGroupExampleInput" id="label_champ_select"class="form-label">Entrez votre question </label>	
				<select class="form-select" aria-label="Default select example" id="form_select">
				</select>				
		</div>
	</div> 

	<!-- SELECT  Nouveau champ select pour le formulaire principal  -->

	<div hidden = "true">
		<div id="new_champ_select_formulaire_principal">		 
			  <option value="1" id="option_nouveau_select">Option 1</option> <!--  COMMENT CHANGER "OPTION 1" ?? -->
		</div>
	</div>

	<!-- SELECT Nouveau champ select pour la boite de dialogue  -->
	<div hidden = "true">
		<div id="new_champ_select_modal">
			<div class="new_select">
				<div class="mb-3">
				  	<label for="new_option_select" class="form-label">Réponse</label>
				    <input type="text" class="form-control" id="new_option_select" >
			 	 </div>
			</div>		 
		</div>
	</div>

	<!-- RADIO Champ Radio avec label de titre pour le formulaire principal  -->
	<div hidden = "true">
		<div id="champ_radio">
			<div class="row">		
				<label for="formGroupExampleInput" id="label_champ_radio"class="form-label">Entrez votre question </label>
				<div id="champ_radio_unique">
				
				</div>		
			</div>
		</div>
	</div>
	<!-- RADIO Nouveau champ radio pour le formulaire principal  -->
	<div hidden = "true">
		<div id="new_champ_radio_formulaire_principal">
			<div id="form_radio_base" class="form_radio_base">		 
				<input class="form-check-input" type="radio" name="" id="input_nouveau_radio">
  				<label class="form-check-label" for="flexRadioDefault1" id="nouveau_label_radio"> Default radio </label>
			</div>
		</div>
	</div>
	<!-- RADIO Nouveau champ radio pour la boite de dialogue  -->
	<div hidden = "true">
		<div id="new_champ_radio_modal">
			<div class="new_radio">
				<div class="mb-3">
				  	<label for="new_option_radio" class="form-label">Réponse</label>
				    <input type="text" class="form-control" id="new_option_radio" >
			 	 </div>
			</div>		 
		</div>
	</div>
	
	<!-- MODAL DE CONNEXION  -->
	
	<script type="text/javascript" src="froala_editor_4.0.13/js/froala_editor.pkgd.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" ></script>
</body>
</html>
