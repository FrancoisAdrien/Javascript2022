<?php

	include('connexion_bd.php');

	if(isset($_POST['id']))
	{
		$id = $_POST['id'];
		
		$supprimer_lecteur = "DELETE FROM lecteur_formulaire WHERE idlecteur=?";
		$requete_prepare= $connexion_bd_projetjs->prepare($supprimer_lecteur);
		$requete_prepare->execute([$id]);

		//echo $id;
	}


	

?>