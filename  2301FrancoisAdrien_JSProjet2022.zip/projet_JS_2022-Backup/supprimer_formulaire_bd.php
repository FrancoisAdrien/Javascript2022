<?php

	include('connexion_bd.php');


	if(isset($_POST['idformulaire']))
	{
		$idformulaire = $_POST['idformulaire'];
		

		$supprimer_options_champ = "DELETE FROM option_champ WHERE idchamp in (SELECT id from champ WHERE idformulaire=:idformulaire)";

		$supprimer_champs = "DELETE FROM champ WHERE idformulaire=:idformulaire";

		$supprimer_formulaire = "DELETE FROM formulaire  WHERE id=:idformulaire";

		$requete_prepare_options_champ= $connexion_bd_projetjs->prepare($supprimer_options_champ);
		$requete_prepare_options_champ->execute(array(':idformulaire'=>$idformulaire));

		$requete_prepare_champs= $connexion_bd_projetjs->prepare($supprimer_champs);
		$requete_prepare_champs->execute(array(':idformulaire'=>$idformulaire));

		$requete_prepare_formulaire= $connexion_bd_projetjs->prepare($supprimer_formulaire);
		$requete_prepare_formulaire->execute(array(':idformulaire'=>$idformulaire));

	}

	if(isset($_POST['idchamp']))
	{
		$idchamp = $_POST['idchamp'];

		$supprimer_options_champ = 'DELETE FROM option_champ WHERE idchamp =:idchamp ';

		$supprimer_champs = 'DELETE FROM champ  WHERE id=:idchamp ';

		$requete_prepare_options_champ= $connexion_bd_projetjs->prepare($supprimer_options_champ);
		$requete_prepare_options_champ->execute(array(':idchamp'=>$idchamp));

		$requete_prepare_champs= $connexion_bd_projetjs->prepare($supprimer_champs);
		$requete_prepare_champs->execute(array(':idchamp'=>$idchamp));

	}

	

?>