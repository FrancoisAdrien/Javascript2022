$(document).ready(function () {

			var prepend_form_initial = $('#prepend_form').html();
			var champ_check_initial =$('#champ_check').html();
			var new_champ_check_formulaire_principal =$('#new_champ_check_formulaire_principal').html();

			var prepend_select_initial = $('#prepend_form_select').html();
			var champ_select_initial =$('#champ_select').html();
			var new_champ_select_formulaire_principal =$('#new_champ_select_formulaire_principal').html();

			var prepend_form_radio_initial = $('#prepend_form_radio').html();
			var champ_radio_initial =$('#champ_radio').html();
			var new_champ_radio_formulaire_principal_initial =$('#new_champ_radio_formulaire_principal').html();

			// Traitement réponse courte

			$('#courte').click(function(){
				//alert("ok");
				// Récupération du titre du champ
				var titre_champ = $('#titre_champ_courte').val();
				$('#label_champ_courte').html(titre_champ);

				// Récupération de la valeur du placeholder
				var description_champ_courte= $('#description_champ_courte').val();
				$('#input_champ_courte').attr('placeholder',description_champ_courte);
			
				// Attribution de l'attribut "checked"
				//var checked = false;
				if($('#check_champ_courte').prop("checked"))
				{
					$('#input_champ_courte').attr('required','true');
					//checked = true;
				}
				
				// Récupération et ajout des informations du champ parametré et ajout au formulaire principal
				var champ_courte = $('#champ_courte').html();
				$('#formulaire_principal').prepend( champ_courte + '<br />');

				/*var type='champ_courte';

				//test_ajax(titre_champ,description_champ_courte,type,checked);
				$.ajax({
						type:"post",
						url:"nouveau_champ_bd_ajax.php",
						data:"titre="+titre_champ + "&description="+description_champ_courte + "&type="+type + "&checked="+checked + "&idformulaire=" +  <?php  $id; ?>,
						success : function(data){
								alert(data);				 
							//$('#alert').html(data);
						}		
					});*/

				// Réinitialisation de la boîte de dialogue
				/*$('#titre_champ_courte').val('');

				$('#description_champ_courte').val('');

				$('#check_champ_courte').removeAttr('checked');*/

				$('#modal_reponse_courte').modal('hide');

				return false;
			});


			$('#longue').click(function(){

			/*	var editor = new FroalaEditor('#example') */

				var titre_champ = $('#titre_champ_longue').val();
				$('#label_champ_longue').html(titre_champ);

				// Récupération de la valeur du placeholder
				var description_champ_longue= $('#description_champ_longue').val();
				$('#input_champ_longue').attr('placeholder',description_champ_longue);
			
				// Attribution de l'attribut "checked"
				//var checked = false;
				if($('#check_champ_longue').prop("checked"))
				{
					$('#input_champ_longue').attr('required','true');
				}
				
				// Récupération et ajout des informations du champ parametré et ajout au formulaire principal
				var champ_longue = $('#champ_longue').html();
				$('#formulaire_principal').prepend(champ_longue);

				/*var type='champ_courte';

				// Réinitialisation de la boîte de dialogue
				/*$('#titre_champ_courte').val('');

				$('#description_champ_courte').val('');

				$('#check_champ_courte').removeAttr('checked');*/

				$('#modal_reponse_longue').modal('hide');

				//return false;
				
				
			});

			$('#select').click(function(){
				
				var titre_champ = $('#titre_champ_select').val();
				$('#champ_select #label_champ_select').html(titre_champ);

				$('#prepend_form_select .new_select ').each(function(){

					var new_option_select = $('#new_option_select' ,this).val();
					$('#new_champ_select_formulaire_principal #option_nouveau_select').html(new_option_select);
					$('#new_champ_select_formulaire_principal #option_nouveau_select').attr('value',new_option_select);

					var new_champ_select_formulaire_principal = $('#new_champ_select_formulaire_principal').html();
					$('#champ_select #form_select').prepend(new_champ_select_formulaire_principal);
					//$('#new_option_select').val('');
					
				});

				var champ_select = $('#champ_select').html();
				$('#formulaire_principal').prepend(champ_select + '<br />');
	
			/*	$('#prepend_form_select').html(prepend_select_initial);
				$('#champ_select').html(champ_select_initial);
				$('#new_champ_select_formulaire_principal').html(new_champ_select_formulaire_principal);

				$('#titre_champ_select').val('');*/

				$('#modal_reponse_select').modal('hide');

				return false;
			});

			$('#addSelect').click(function(){
				var new_champ_select_modal =$('#new_champ_select_modal').html();
				$('#prepend_form_select').append(new_champ_select_modal);

				return false;
			})

			// Traitement réponse checkbox

			$('#check').click(function(){

				// On récupère le titre dans la boite de dialogue et on l'attribue au label de notre champ paramétré
				var titre_champ = $('#titre_champ_check').val();
				$('#champ_check #label_champ_check').html(titre_champ);

				// Pour chaque options dans le modal 
				$('#prepend_form .new_check').each(function(){
					// On récupère le nom de l'option dans la boite de dialogue et on l'attribue à un nouveau champ paramétré
					var new_option_check = $('#new_option_check' ,this).val();
					$('#new_champ_check_formulaire_principal #nouveau_label_check').html(new_option_check);
					$('#new_champ_check_formulaire_principal #input_nouveau_check').attr('name',new_option_check);

					// On ajoute toutes ces options dans le champ paramétré où se trouve le label
					var new_champ_check_formulaire_principal = $('#new_champ_check_formulaire_principal').html();
					$('#champ_check #champ_check_unique').prepend(new_champ_check_formulaire_principal);

					//$('#new_option_check').val('');
					
				});

				//On ajoute notre checkbox au formulaire principal
				var champ_check = $('#champ_check').html();
				$('#formulaire_principal').prepend(champ_check + '<br />');

				
				// réinitialisation du modal
				

				// réinitialisation des champs paramétré
			/*	$('#champ_check').html(champ_check_initial);
				$('#new_champ_check_formulaire_principal').html(new_champ_check_formulaire_principal);
				$('#titre_champ_check').val('');*/

				$('#modal_reponse_check').modal('hide');

				return false;
									
			});

			$('#addCheck').click(function(){
				var new_champ_check_modal =$('#new_champ_check_modal').html();
				$('#prepend_form').append(new_champ_check_modal);

			return false;
			});

			// Traitement réponse radio

			$('#radio').click(function(){

				// On récupère le titre dans la boite de dialogue et on l'attribue au label de notre champ paramétré
				var titre_champ = $('#titre_champ_radio_test').val();
				$('#champ_radio #label_champ_radio').html(titre_champ);

				// Pour chaque options dans le modal 
				$('#prepend_form_radio .new_radio').each(function(){

					// On récupère le nom de l'option dans la boite de dialogue et on l'attribue à un nouveau champ paramétré
					var new_option_radio = $('#new_option_radio' ,this).val();
					$('#new_champ_radio_formulaire_principal #nouveau_label_radio').html(new_option_radio);
					$('#new_champ_radio_formulaire_principal #input_nouveau_radio').attr('name','radioDefault');

					// On ajoute toutes ces options dans le champ paramétré où se trouve le label
					var new_champ_radio_formulaire_principal = $('#new_champ_radio_formulaire_principal').html();
					$('#champ_radio #champ_radio_unique').prepend(new_champ_radio_formulaire_principal);

					//$('#new_option_radio').val('');
					
				});

				//On ajoute notre radiobox au formulaire principal
				var champ_radio = $('#champ_radio').html();
				$('#formulaire_principal').prepend(champ_radio + '<br />');

				// réinitialisation du modal
			/*	$('#prepend_form_radio').html(prepend_form_radio_initial);

				// réinitialisation des champs paramétré
				$('#champ_radio').html(champ_radio_initial);
				$('#new_champ_radio_formulaire_principal').html(new_champ_radio_formulaire_principal_initial);*/
				//$('#titre_champ_radio').val('');

				$('#modal_reponse_radio').modal('hide');

				return false;
									
			}); 

			$('#addRadio').click(function(){
				var new_champ_radio_modal =$('#new_champ_radio_modal').html();
				$('#prepend_form_radio').append(new_champ_radio_modal);

			return false;
			});

/*
			function test_ajax(titre_champ,description_champ_courte,type,checked){
							$.ajax({
						type:"post",
						url:"nouveau_champ_bd_ajax.php",
						data:"titre="+titre_champ + "&description="+description_champ_courte + "&type="+type + "&checked="+checked + "&idformulaire=" +  <?php  $id; ?>,
						success : function(data){
								alert(data);				 
							//$('#alert').html(data);
						}		
					});
			} */
		});