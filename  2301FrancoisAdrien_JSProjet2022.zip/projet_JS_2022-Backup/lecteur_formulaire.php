<!DOCTYPE html>
<html>
<head>
	<title>Lecture formulaire</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="projetjs.css">
		
	
	<script type="text/javascript" src="jquery-3.6.0.min.js"></script>

	<script type="text/javascript"> </script>
	<script type="text/javascript">
	</script>
	<script type="text/javascript">
    
    $(document).ready(function( ) {	

    $.ajax({
          type:"post",
          url:"liste_formulaire_en_lecture_ajax_serveur.php",
          data: "idutilisateur="+sessionStorage.getItem('id_utilisateur'),
          success : function(data){
            $('#body_tableau_liste_formulaire_en_lecture').html(data);
          }

      });							
    });


  </script> 
</head>
<body>

<nav class="navbar navbar-expand-xxl navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="accueil.php">Projet Javascript 2022</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link " aria-current="page" href="accueil.php">Édition formulaire</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="lecteur_formulaire.php">Lecture formulaire</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="repondant_formulaire.php">Réponse formulaire</a>
        </li>
      </ul>
    </div>
   		 <ul class="navbar-nav ml-auto" id="navbarNav">
	        <li class="nav-item">
	          <a class="nav-link" href="deconnexion_utilisateur.php">Déconnexion</a>
	        </li>
        </ul>
  	</div>
</nav>
	<br/>
	<h1>Liste de vos formulaires en lecture</h1>
	<br/>
<table class="table" table-striped">
  <thead>
    <tr> 
    	<th scope="col">#</th>
      <th scope="col">Code</th>
      <th scope="col">Titre</th>
      <th scope="col">Date début</th>
      <th scope="col">Date limite</th>
      <th scope="col">Créateur</th>  
      <th scope="col">Actions</th>  
    </tr>
  </thead>
  <tbody id="body_tableau_liste_formulaire_en_lecture">

  </tbody>
</table>




	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" ></script>
</body>
</html>