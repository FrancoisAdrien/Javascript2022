<script type="text/javascript">
	sessionStorage.clear();
	sessionStorage.setItem('id_utilisateur','');
	document.location.href = "connexion_utilisateur.php";
</script>