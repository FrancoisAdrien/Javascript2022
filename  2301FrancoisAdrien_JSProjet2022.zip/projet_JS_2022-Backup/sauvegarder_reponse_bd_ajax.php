<?php

      include('connexion_bd.php');

      	if(isset($_POST['json_reponse']) && isset($_POST['idformulaire']) && isset($_POST['idutilisateur']))
      	{
      		$json_reponse=$_POST['json_reponse'];
      		$idformulaire=$_POST['idformulaire'];
      		$idutilisateur=$_POST['idutilisateur'];


      		$requete_reponse_bd = $connexion_bd_projetjs->query('SELECT * FROM reponse WHERE idrepondant = \'' . $idutilisateur . '\'  AND idformulaire = \'' . $idformulaire . '\' ');

      		$reponse_bd = $requete_reponse_bd->fetch();

      		if($reponse_bd['id'])
      		{
      			$update_reponse_formulaire =$connexion_bd_projetjs->prepare("UPDATE reponse set json_reponse=:json_reponse WHERE idformulaire=:idformulaire AND idrepondant=:idrepondant ");

				$update_reponse_formulaire->execute(array(

					'json_reponse' => $json_reponse,
					'idformulaire' => $idformulaire,
					'idrepondant' => $idutilisateur,
				));
      		}else
      		{
      			$insertion_reponse_formulaire =$connexion_bd_projetjs->prepare("INSERT INTO reponse (json_reponse,idformulaire,idrepondant) VALUES (:json_reponse,:idformulaire,:idrepondant)"); 

				$insertion_reponse_formulaire->execute(array(

				'json_reponse' => $json_reponse,
				'idformulaire' => $idformulaire,
				'idrepondant' => $idutilisateur,
			));
      		}

      	}


		

	?>
