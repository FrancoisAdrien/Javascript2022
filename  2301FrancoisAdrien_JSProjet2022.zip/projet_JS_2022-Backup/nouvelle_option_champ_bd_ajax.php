<?php

	include('connexion_bd.php');
	

	if(isset($_POST['titre']) && isset($_POST['tab_options']) && isset($_POST['type']) && isset($_POST['idformulaire']))
		{ 

			$titre_champ = $_POST['titre'];
			$tab_options_check = $_POST['tab_options'];
			$type = $_POST['type'];
			$idformulaire = $_POST['idformulaire'];

			$description_champ= null;
			$checked=null;

			$array_tab_options_check=explode(",",$tab_options_check );

			$insertion_champ =$connexion_bd_projetjs->prepare('INSERT INTO champ (titre_champ,description_champ,type,checked,idformulaire) VALUES (:titre_champ,:description_champ,:type,:checked,:idformulaire)'); 

			$insertion_champ->execute(array(
				'titre_champ' => $titre_champ,
				'description_champ' => $description_champ,
				'type' => $type,
				'checked' => $checked,
				'idformulaire' => $idformulaire,
			)); 

			
			$idchamp = $connexion_bd_projetjs->lastInsertId(); 
			
			$insertion_option_champ =$connexion_bd_projetjs->prepare('INSERT INTO option_champ (titre_option,idchamp) VALUES (:titre_option,:idchamp)');

		
			foreach($array_tab_options_check as $options_check)
			{
				$insertion_option_champ->execute(array(
					'titre_option' => $options_check,
					'idchamp' => $idchamp, 
				));
			}

		}
	
		//echo $array_tab_options_check[0].' '. $array_tab_options_check[1];
?>