<?php

	include('connexion_bd.php');

	if(isset($_POST['pseudorepondant']))
		{		
			$pseudorepondant = $_POST['pseudorepondant'];


	      $pseudorepondant_bd = $connexion_bd_projetjs->query('SELECT * FROM utilisateur WHERE pseudo = \'' . $pseudorepondant . '\' '); 

	      $repondant = $pseudorepondant_bd->fetch();

	      		
	      if(isset($_POST['idformulaire']))
	      {

	      	$idformulaire = $_POST['idformulaire'];

	      	$insertion_repondant_formulaire =$connexion_bd_projetjs->prepare('INSERT INTO repondant_formulaire (idformulaire,idrepondant) VALUES (:idformulaire,:idrepondant)'); 

			$insertion_repondant_formulaire->execute(array(

				'idformulaire' => $idformulaire,
				'idrepondant' => $repondant['id'],
			));

	      }

		}


?>

<tr>
      <th scope="row"><?php echo $repondant['id'];?></th>
      <td><?php echo $repondant['nom'];?></td>
      <td><?php echo $repondant['prenom'];?></td>
      <td><?php echo $repondant['email'];?></td>
      <td><?php echo $repondant['telephone'];?></td>
      <td><?php echo $repondant['pseudo'];?></td>
      <td>
      	<a class="btn btn-danger"  id="boutton_supprimer_formulaire" href="supprimer_utilisateur.php?id=<?php echo $repondant['id'];?>" role="button">Supprimer</a>
      </td>
    </tr>