-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  mar. 23 août 2022 à 17:59
-- Version du serveur :  5.7.26
-- Version de PHP :  7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projetjs`
--

-- --------------------------------------------------------

--
-- Structure de la table `champ`
--

DROP TABLE IF EXISTS `champ`;
CREATE TABLE IF NOT EXISTS `champ` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre_champ` varchar(200) NOT NULL,
  `description_champ` varchar(200) DEFAULT NULL,
  `type` varchar(200) NOT NULL,
  `checked` tinyint(1) DEFAULT NULL,
  `idformulaire` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idformulaire` (`idformulaire`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `champ`
--

INSERT INTO `champ` (`id`, `titre_champ`, `description_champ`, `type`, `checked`, `idformulaire`) VALUES
(20, 'Plats préférés', NULL, 'champ_check', NULL, 3),
(22, 'Couleur préférée', NULL, 'champ_select', NULL, 3),
(24, 'Sexe', NULL, 'champ_radio', NULL, 3),
(32, 'Test', 'Test test', 'champ_courte', 0, 9),
(33, 'Animal préféré', NULL, 'champ_check', NULL, 9),
(34, 'Sexe', NULL, 'champ_radio', NULL, 9),
(35, 'Marque préférée', NULL, 'champ_select', NULL, 9),
(36, 'Nom', 'Entrez votre nom', 'champ_courte', 0, 9),
(37, 'Main forte', NULL, 'champ_radio', NULL, 9),
(39, 'Test', 'entrez le test', 'champ_longue', 0, 4),
(40, 'Prenom', 'Entrez prenom', 'champ_courte', 0, 11),
(41, 'Aliments préférés', NULL, 'champ_select', NULL, 11),
(42, 'Equipe préférée', NULL, 'champ_radio', NULL, 11);

-- --------------------------------------------------------

--
-- Structure de la table `formulaire`
--

DROP TABLE IF EXISTS `formulaire`;
CREATE TABLE IF NOT EXISTS `formulaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre` varchar(200) NOT NULL,
  `code` varchar(200) NOT NULL,
  `datedebut` date DEFAULT NULL,
  `datelimite` date DEFAULT NULL,
  `idutilisateur` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idutilisateur` (`idutilisateur`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `formulaire`
--

INSERT INTO `formulaire` (`id`, `titre`, `code`, `datedebut`, `datelimite`, `idutilisateur`) VALUES
(3, 'TestNumeroId', '003', NULL, NULL, 2),
(4, 'Formulaire Nico', '004', NULL, NULL, 4),
(9, 'Test date formulaire', '900', NULL, '2022-08-21', 2),
(10, 'TEst nouveau', '850', NULL, '2022-08-22', 4),
(11, 'Test Encodage', '850', NULL, '2022-08-25', 2),
(16, 'Nouveau Formulaire', '563', '2022-08-24', '2022-08-25', 2);

-- --------------------------------------------------------

--
-- Structure de la table `lecteur_formulaire`
--

DROP TABLE IF EXISTS `lecteur_formulaire`;
CREATE TABLE IF NOT EXISTS `lecteur_formulaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idformulaire` int(11) NOT NULL,
  `idlecteur` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idformulaire` (`idformulaire`),
  KEY `idlecteur` (`idlecteur`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `lecteur_formulaire`
--

INSERT INTO `lecteur_formulaire` (`id`, `idformulaire`, `idlecteur`) VALUES
(5, 3, 4),
(13, 3, 1),
(14, 11, 6),
(15, 16, 6);

-- --------------------------------------------------------

--
-- Structure de la table `option_champ`
--

DROP TABLE IF EXISTS `option_champ`;
CREATE TABLE IF NOT EXISTS `option_champ` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `titre_option` varchar(200) NOT NULL,
  `idchamp` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idchamp` (`idchamp`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `option_champ`
--

INSERT INTO `option_champ` (`id`, `titre_option`, `idchamp`) VALUES
(7, 'Frites', 20),
(6, 'Poulet', 20),
(5, 'Riz', 20),
(9, 'Rouge', 22),
(10, 'Bleu', 22),
(11, 'Jaune', 22),
(13, 'Homme', 24),
(14, 'Femme', 24),
(25, 'chat', 33),
(24, 'chien', 33),
(26, 'tortue', 33),
(27, 'homme', 34),
(28, 'femme', 34),
(29, 'Nike', 35),
(30, 'Adidas', 35),
(31, 'New balance', 35),
(32, 'Droitier', 37),
(33, 'Gaucher', 37),
(39, 'Brocolis', 41),
(38, 'Viandes', 41),
(37, 'Frites', 41),
(40, 'Real Madrid', 42),
(41, 'Fc Barcelone', 42);

-- --------------------------------------------------------

--
-- Structure de la table `repondant_formulaire`
--

DROP TABLE IF EXISTS `repondant_formulaire`;
CREATE TABLE IF NOT EXISTS `repondant_formulaire` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `idformulaire` int(11) NOT NULL,
  `idrepondant` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idformulaire` (`idformulaire`),
  KEY `idrepondant` (`idrepondant`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `repondant_formulaire`
--

INSERT INTO `repondant_formulaire` (`id`, `idformulaire`, `idrepondant`) VALUES
(1, 3, 4),
(2, 9, 4),
(3, 11, 4),
(4, 11, 6),
(5, 16, 6);

-- --------------------------------------------------------

--
-- Structure de la table `reponse`
--

DROP TABLE IF EXISTS `reponse`;
CREATE TABLE IF NOT EXISTS `reponse` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `json_reponse` varchar(255) NOT NULL,
  `idformulaire` int(11) NOT NULL,
  `idrepondant` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idformulaire` (`idformulaire`),
  KEY `idrepondant` (`idrepondant`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `reponse`
--

INSERT INTO `reponse` (`id`, `json_reponse`, `idformulaire`, `idrepondant`) VALUES
(19, '{\"Prenom\": \"Sarah\",\"Aliments préférés\": \"Viandes\",\"Equipe préférée\": \"Fc Barcelone\"}', 11, 6),
(15, '{\"Test\": \"dada\",\"Nom\": \"tata\",\"Marque préférée\": \"Adidas\",\"Animal préféré\": \"chien,tortue\",\"Sexe\": \"femme\",\"Main forte\": \"Gaucher\"}', 9, 4),
(27, '{\"Prenom\": \"Nicolas\",\"Aliments préférés\": \"Frites\",\"Equipe préférée\": \"Real Madrid\"}', 11, 4);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

DROP TABLE IF EXISTS `utilisateur`;
CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `prenom` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `telephone` varchar(200) NOT NULL,
  `pseudo` varchar(200) NOT NULL,
  `mdp` varchar(200) NOT NULL,
  `etat` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `nom`, `prenom`, `email`, `telephone`, `pseudo`, `mdp`, `etat`) VALUES
(1, 'François', 'Adrien', 'adrien.francois07@gmail.com', '0496387761', 'pseudoTEST', 'test', 'test'),
(2, 'François', 'Adrien', 'adrien.francois07@gmail.com', '0496387761', 'Adri', '12345', '1'),
(4, 'François', 'Nicolas', 'nicolas@gmail.com', '0481101112', 'Nicouz', '5555', '1'),
(6, 'Cambrelin', 'Sarah', 'sarah.cambrelin@gmail.com', '0741258963', 'Sarah', '2608', '1');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `champ`
--
ALTER TABLE `champ`
  ADD CONSTRAINT `champ_ibfk_1` FOREIGN KEY (`idformulaire`) REFERENCES `formulaire` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
