<?php

	include('connexion_bd.php');

	if(isset($_POST['idformulaire']))
		{		
			$idformulaire = $_POST['idformulaire'];


	      $liste_repondants_formulaire_bd = $connexion_bd_projetjs->query('SELECT * FROM repondant_formulaire rf inner join utilisateur u  on (rf.idrepondant=u.id) WHERE  rf.idformulaire =  '.$idformulaire.'  '); // where id = valeur de l'utilisateur


	      $liste_repondants_formulaire = $liste_repondants_formulaire_bd->fetchAll();

		}

?>


 <?php 

     $compteur=0;

  	foreach($liste_repondants_formulaire as $repondant_formulaire)
	  	{ 
	  		$compteur++; 	 
  	?>
    <tr>
      <th scope="row"><?php echo $compteur;?></th>
      <td><?php echo $repondant_formulaire['nom'];?></td>
      <td><?php echo $repondant_formulaire['prenom'];?></td>
      <td><?php echo $repondant_formulaire['email'];?></td>
      <td><?php echo $repondant_formulaire['telephone'];?></td>
      <td><?php echo $repondant_formulaire['pseudo'];?></td>
      <td>
      	<a class="btn btn-danger"  id="boutton_supprimer_formulaire" href="supprimer_utilisateur.php?id=<?php echo $repondant_formulaire['id'];?>" role="button">Supprimer</a>
      </td>
    </tr>
    <?php 
		} 
	?>