<!DOCTYPE html>
<html>
<head>
	<title>Modifier champs formulaire</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="projetjs.css">
	<link href="froala_editor_4.0.13/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<script type="text/javascript" src="jquery-3.6.0.min.js"></script>
	<script type="text/javascript" src ="script.js"></script>
	<?php  
		if(isset($_GET['id']))
		{
			$idformulaire = $_GET['id'];
		}
	?>
	<script type="text/javascript">
	
	$(document).ready(function () {

			

			$.ajax({
				type:"post",
				url:"retrieve_code_titre_formulaire_bd.php",
				data:"id=" + <?php  print $idformulaire; ?>,
				
				success : function(data){
						//alert(data);				 
					$('#alert').html(data);
				}		
			});

			$.ajax({
				type:"post",
				url:"retrieve_champs_formulaire_bd.php",
				data:"id=" + <?php  print $idformulaire; ?>,
				success : function(data){
						//alert(data);				 
					$('#formulaire_principal').html(data);
				}		
			});


			return false; 
		});

</script>
	<script type="text/javascript">
		
		$(document).ready(function () {

			var prepend_form_initial = $('#prepend_form').html();
			var champ_check_initial =$('#champ_check').html();
			var new_champ_check_formulaire_principal =$('#new_champ_check_formulaire_principal').html();

			var prepend_select_initial = $('#prepend_form_select').html();
			var champ_select_initial =$('#champ_select').html();
			var new_champ_select_formulaire_principal =$('#new_champ_select_formulaire_principal').html();

			var prepend_form_radio_initial = $('#prepend_form_radio').html();
			var champ_radio_initial =$('#champ_radio').html();
			var new_champ_radio_formulaire_principal_initial =$('#new_champ_radio_formulaire_principal').html();

			$('#courte').click(function(){
				var checked = 0;

				var titre = $('#titre_champ_courte').val();
				var description = $('#description_champ_courte').val();
				var type='champ_courte';

				if($('#check_champ_courte').prop("checked"))
				{
					checked=1;
				}
				if(titre == '')
				{
					alert('Veuillez entrez le titre');
				}
				else
				{
				$.ajax({
						type:"post",
						url:"nouveau_champ_bd_ajax.php",
						data:"titre="+titre + "&description="+description + "&type="+type + "&checked="+checked + "&idformulaire=" +  <?php print $idformulaire; ?>,
						success : function(data){
								//alert(data);				 
							//$('#alert').html(data);
						}		
					});

					$('#titre_champ_courte').val('');

					$('#description_champ_courte').val('');

					$('#check_champ_courte').removeAttr('checked');
					return false; 
				}
					
				});
			$('#longue').click(function(){

				var checked = 0;

				var titre = $('#titre_champ_longue').val();
				var description = $('#description_champ_longue').val();
				var type='champ_longue';

				if($('#check_champ_longue').prop("checked"))
				{
					checked=1;
				}
				if(titre == '')
				{
					alert('Veuillez entrez le titre');
				}
				else
				{
				$.ajax({
						type:"post",
						url:"nouveau_champ_bd_ajax.php",
						data:"titre="+titre + "&description="+description + "&type="+type + "&checked="+checked + "&idformulaire=" +  <?php print $idformulaire; ?>,
						success : function(data){
								//alert(data);				 
							//$('#alert').html(data);
						}		
					});

					$('#titre_champ_longue').val('');

					$('#description_champ_longue').val('');

					$('#check_champ_longue').removeAttr('checked');
				return false; 
				}
					
				});
			$('#check').click(function(){
				
				var tab_options = [];
				console.log(tab_options);

				var titre_champ_check = $('#titre_champ_check').val();
				var type='champ_check';
				
				$('#prepend_form .new_check').each(function()
				{
					//alert($('#new_option_check' ,this).val());
					tab_options.push($('#new_option_check' ,this).val());
				});
					//console.log(tab_options);

				if(titre_champ_check == '')
				{
					alert('Veuillez entrez le titre');
				}
				else
				{
					
				$.ajax({
						type:"post",
						url:"nouvelle_option_champ_bd_ajax.php",
						data:"titre="+titre_champ_check + "&tab_options="+tab_options + "&type="+type + "&idformulaire=" +  <?php print $idformulaire; ?>,
						success : function(data){
								console.log(data);				 
						}		
					});
				// réinitialisation du modal
				$('#prepend_form').html(prepend_form_initial);

				$('#champ_check').html(champ_check_initial);
				$('#new_champ_check_formulaire_principal').html(new_champ_check_formulaire_principal);
				$('#titre_champ_check').val('');  

				return false; 
				}

			});

			$('#select').click(function(){
				
				var tab_options = [];
				console.log(tab_options);

				var titre_champ_select = $('#titre_champ_select').val();
				var type='champ_select';
				
				$('#prepend_form_select .new_select').each(function()
				{
					//alert($('#new_option_check' ,this).val());
					tab_options.push($('#new_option_select' ,this).val());
				});
					console.log(tab_options);

				if(titre_champ_select == '')
				{
					alert('Veuillez entrez le titre');
				}
				else
				{
					
				$.ajax({
						type:"post",
						url:"nouvelle_option_champ_bd_ajax.php",
						data:"titre="+titre_champ_select + "&tab_options="+tab_options + "&type="+type + "&idformulaire=" +  <?php print $idformulaire; ?>,
						success : function(data){
								console.log(data);				 
						}		
					});
				// réinitialisation du modal
				$('#prepend_form_select').html(prepend_select_initial);
				$('#champ_select').html(champ_select_initial);
				$('#new_champ_select_formulaire_principal').html(new_champ_select_formulaire_principal);

				$('#titre_champ_select').val('');  

				return false; 
				}

			});

			$('#radio').click(function(){
				
				var tab_options = [];
				//console.log(tab_options);

				var titre_champ_radio = $('#titre_champ_radio_test').val();
				console.log(titre_champ_radio);
				var type='champ_radio';
				
				$('#prepend_form_radio .new_radio').each(function()
				{
					tab_options.push($('#new_option_radio' ,this).val());
				});
					//console.log(tab_options);

				if(titre_champ_radio == '')
				{
					alert('Veuillez entrez le titre');
				}
				else
				{
						
				$.ajax({
						type:"post",
						url:"nouvelle_option_champ_bd_ajax.php",
						data:"titre="+titre_champ_radio + "&tab_options="+tab_options + "&type="+type + "&idformulaire=" +  <?php print $idformulaire; ?>,
						success : function(data){
								console.log(data);				 
						}		
					});

				$('#prepend_form_radio').html(prepend_form_radio_initial);

				// réinitialisation des champs paramétré
				$('#champ_radio').html(champ_radio_initial);
				$('#new_champ_radio_formulaire_principal').html(new_champ_radio_formulaire_principal_initial);
				$('#titre_champ_radio').val(''); 

					return false; 
				}

			});

			$('#modal_supprimer_champ_formulaire').on('show.bs.modal', function (e) {

		    var idchamp = $(e.relatedTarget).attr('data-id');
		    $(this).find('.idchamp').text(idchamp);

		    $('#btn_supprimer_champ_formulaire').click(function(){
		    	console.log(idchamp);
		    	$.ajax({
					type:"post",
					url:"supprimer_formulaire_bd.php",
					data:"idchamp="+idchamp,
					success : function(data){				 
						//alert(data);			
					}		
				});

		    });
	    
		})
		});	
	</script>
</head>
<body>
	<nav class="navbar navbar-expand-xxl navbar-dark bg-primary">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="accueil.php">Projet Javascript 2022</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarNav">
	      <ul class="navbar-nav">
	        <li class="nav-item">
	          <a class="nav-link active" aria-current="page" href="#">Édition formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="lecteur_formulaire.php">Lecture formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Réponse formulaire</a>
	        </li>
	      </ul>
	    </div>
	        <ul class="navbar-nav ml-auto" id="navbarNav">
		        <li class="nav-item">
		          <a class="nav-link" href="deconnexion_utilisateur.php">Déconnexion</a>
		        </li>
	        </ul>
	  </div>
	</nav>

	<br/>
		<a class="btn btn-primary" href="accueil.php" role="button" >Listes des formulaires </a>
	<br/>
	<br/>
		<h1>Gestion des champs d'un formulaire</h1>
	<br/>

	<div id="alert" class="alert alert-primary" role="alert">
  		
	</div>

	<div class="container">
  		<div class="row">
    		<div class="col-lg-12">
      			<form id="formulaire_principal"></form>
   			</div>
   		</div>
   		<div class="row">
		    <div class="col-lg-12">	      
				<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal_reponse_courte">Réponse courte</button>
				<button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modal_reponse_longue">Réponse longue</button>
				<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modal_reponse_select">Liste</button>
				<button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#modal_reponse_check" >Check</button>
				<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal_reponse_radio" >Radio</button>
		    </div>
  		</div>
	</div>

	<div class="modal fade" id="modal_supprimer_champ_formulaire" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Supprimer le champ du formulaire</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	     	<form method="post">
	      		<div class="modal-body">       
					 <p> Êtes vous sûr de vouloir supprimer le champ du formulaire ?</p>
				  <div class="modal-footer">
			        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
			        <button type="submit" id="btn_supprimer_champ_formulaire" class="btn btn-danger">Supprimer</button>
			      </div>
			
	      		</div>
	      </form>
	    </div>
	  </div>
	</div>



	<?php include('code_html_champs_parametres.php'); ?>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" ></script>

</body>
</html>