<!DOCTYPE html>
<html>
<head>
	<title>Inscription utilisateur</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="produits.css">
	<link href="froala_editor_4.0.13/css/froala_editor.pkgd.min.css" rel="stylesheet" type="text/css" />
	
	<script type="text/javascript" src="jquery-3.6.0.min.js"></script> 
	
	<script type="text/javascript">
	
	$(document).ready(function () {

		$('form').submit(function(){
			var pseudo = $('#pseudo').val();
			var mdp = $('#mdp').val();
			sessionStorage.clear();
			$.ajax({
				type:"post",
				url:"check_connexion_utilisateur_bd_ajax.php",
				data:"pseudo="+pseudo + "&mdp="+mdp,
				success : function(data){
					sessionStorage.setItem('id_utilisateur',data);					 
					document.location.href = "accueil.php";
				}		
			});
			return false; 
		});

	});
</script>

</head>

<body>
	<nav class="navbar navbar-expand-xxl navbar-dark bg-primary">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="accueil.php">Projet Javascript 2022</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarNav">
	      <ul class="navbar-nav">
	     <!--   <li class="nav-item">
	          <a class="nav-link active"  href="#">Édition formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Lecture formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Réponse formulaire</a>
	        </li>-->
	        <li class="nav-item">
          		<a class="nav-link"  aria-current="page" href="inscription_utilisateur.php">Inscription</a>
       		</li>
	      </ul>
	    </div>
	  </div>
	</nav>
	<form method="post">
		   <div class="mb-3">
		    <label for="pseudo" class="form-label">Pseudo</label>
		    <input type="text" class="form-control" id="pseudo" name="pseudo">
		  </div>
		   <div class="mb-3">
		    <label for="mdp" class="form-label">Mdp</label>
		    <input type="password" class="form-control" id="mdp" name="mdp">
		  </div>
		  <button type="submit" class="btn btn-success">Se connecter</button>
		  <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Fermer</button>
		</form>
</body>
</html>