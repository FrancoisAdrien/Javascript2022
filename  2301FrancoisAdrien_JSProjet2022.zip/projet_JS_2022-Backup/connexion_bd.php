<?php
		try {
			 $connexion_bd_projetjs = new PDO('mysql:host=localhost;dbname=projetjs;charset=utf8','root','');
		} catch (Exception $e) {
			echo 'Erreur lors de la connexion à la base de données';
		
		}

	?>