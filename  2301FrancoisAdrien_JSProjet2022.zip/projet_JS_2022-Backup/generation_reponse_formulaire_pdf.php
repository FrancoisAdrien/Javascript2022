
<?php

	include('connexion_bd.php');

  if(isset($_GET['id']))
  {
    $idformulaire = $_GET['id'];

    $formulaire_bd = $connexion_bd_projetjs->query('SELECT * FROM formulaire WHERE id = \'' . $idformulaire . '\' '); 

    $formulaire = $formulaire_bd->fetch();

    $reponse_bd = $connexion_bd_projetjs->query('SELECT r.json_reponse as json_reponse, r.idformulaire as idformulaire, r.idrepondant as idrepondant, u.prenom as prenom, u.nom as nom, u.pseudo as pseudo FROM reponse r inner join utilisateur u on (r.idrepondant = u.id) WHERE idformulaire = \'' . $idformulaire . '\' '); 

    $reponses_formulaire = $reponse_bd->fetchALL();


    $champ_bd = $connexion_bd_projetjs->query('SELECT * FROM champ WHERE idformulaire = \'' . $idformulaire . '\' '); 

    $liste_champs = $champ_bd->fetchALL();


  }

  require('./fpdf184/fpdf.php');

  $pdf = new FPDF();
  $pdf->AddPage();
  $pdf->SetFont('Arial','B',16);

 
  $pdf->Cell(40,10,utf8_decode('Titre du formulaire : '.$formulaire['titre']));
  $pdf->Ln();

  foreach($reponses_formulaire as $reponse)
  {
    $json_reponse=json_decode($reponse['json_reponse']);
     $pdf->Ln();
     $pdf->Cell(40,10,utf8_decode('Répondant au formulaire : '.$reponse['nom'].' '.$reponse['prenom']));
     $pdf->Ln();
      $pdf->Ln();
    foreach ($liste_champs as $champ) 
    {
      $titre_champ= $champ['titre_champ'];

      $pdf->Cell(40,10,utf8_decode($titre_champ.' : '.$json_reponse->$titre_champ));
       $pdf->Ln();

    }
     
  }


  $pdf->Output();


?>
