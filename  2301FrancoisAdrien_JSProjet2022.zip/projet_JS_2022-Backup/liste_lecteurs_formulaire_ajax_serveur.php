<?php

	include('connexion_bd.php');

	if(isset($_POST['idformulaire']))
		{		
			$idformulaire = $_POST['idformulaire'];


	      $liste_lecteurs_formulaire_bd = $connexion_bd_projetjs->query('SELECT * FROM lecteur_formulaire lf inner join utilisateur u  on (lf.idlecteur=u.id) WHERE  lf.idformulaire =  '.$idformulaire.'  '); // where id = valeur de l'utilisateur


	      $liste_lecteurs_formulaire = $liste_lecteurs_formulaire_bd->fetchAll();



		}

?>


 <?php 

     $compteur=0;

  	foreach($liste_lecteurs_formulaire as $lecteur_formulaire)
	  	{ 
	  		$compteur++; 	 
  	?>
    <tr>
      <th scope="row"><?php echo $compteur;?></th>
      <td><?php echo $lecteur_formulaire['nom'];?></td>
      <td><?php echo $lecteur_formulaire['prenom'];?></td>
      <td><?php echo $lecteur_formulaire['email'];?></td>
      <td><?php echo $lecteur_formulaire['telephone'];?></td>
      <td><?php echo $lecteur_formulaire['pseudo'];?></td>
      <td>
      	<!--<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal_supprimer_lecteur" >+ Nouveau lecteur</button> -->
      	<a class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal_supprimer_lecteur" data-id="<?php echo $lecteur_formulaire['id'];?>" href="" role="button">Supprimer</a>
      </td>
    </tr>

    <?php 
		} 
	?>