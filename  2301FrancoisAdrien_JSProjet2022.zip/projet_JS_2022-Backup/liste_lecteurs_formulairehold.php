<!DOCTYPE html>
<html>
<head>
	<title>Liste lecteurs formulaires</title>
		<title>Accueil</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="projetjs.css">
	
	<script type="text/javascript" src="jquery-3.6.0.min.js"></script>

	<?php  
		if(isset($_GET['id']))
		{
			$idformulaire = $_GET['id'];
		}
	?>
	<script type="text/javascript">
		$(document).ready(function () {

				$.ajax({
					type:"post",
					url:"retrieve_code_titre_formulaire_bd.php",
					data:"id=" + <?php  print $idformulaire; ?>,
					
					success : function(data){
							//alert(data);				 
						$('#alert').html(data);
					}		
				});

				$.ajax({
					type:"post",
					url:"liste_lecteurs_formulaire_ajax_serveur.php",
					data:"idformulaire=" + <?php  print $idformulaire; ?>,
					
					success : function(data){
							//alert(data);				 
						$('#body_tableau_liste_lecteurs').html(data);
					}		
				});

				$('form').submit(function(){
					var pseudolecteur = $('#pseudolecteur').val();
					
					$.ajax({

						type:"post",
						url:"lecteurs_bd_ajax.php",
						data:"pseudolecteur="+pseudolecteur +  "&idformulaire=" + <?php  print $idformulaire; ?>,// rajouter l'id de l'utilisateur
						success : function(data){				 
							alert(data);
						}		
					});
					return false; 
				});






			});
	</script>
</head>
<body>
	
	<nav class="navbar navbar-expand-xxl navbar-dark bg-primary">
	  <div class="container-fluid">
	    <a class="navbar-brand" href="accueil.php">Projet Javascript 2022</a>
	    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
	      <span class="navbar-toggler-icon"></span>
	    </button>
	    <div class="collapse navbar-collapse" id="navbarNav">
	      <ul class="navbar-nav">
	        <li class="nav-item">
	          <a class="nav-link active" aria-current="page" href="#">Édition formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Lecture formulaire</a>
	        </li>
	        <li class="nav-item">
	          <a class="nav-link" href="#">Réponse formulaire</a>
	        </li>
	      </ul>
	    </div>
	   		 <ul class="navbar-nav ml-auto" id="navbarNav">
	            <li class="nav-item">
		          <a class="nav-link" href="inscription_utilisateur.php">Inscription</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link" href="connexion_utilisateur.php">Connexion</a>
		        </li>
		        <li class="nav-item">
		          <a class="nav-link" href="deconnexion_utilisateur.php">Déconnexion</a>
		        </li>
	        </ul>
	  	</div>
	</nav>

	<br/>
	<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal_nouveau_lecteur" >+ Nouveau lecteur</button>
	<br/>
	<br/>
	<h1>Liste des lecteurs du formulaire <?php  print $idformulaire; ?> </h1>
	<br/>

	<div id="alert" class="alert alert-primary" role="alert">
  		
	</div>

	<table class="table" table-striped">
	  <thead>
	    <tr> 
	    	<th scope="col">#</th>
	      <th scope="col">Nom</th>
	      <th scope="col">Prenom</th>
	      <th scope="col">Email</th>
	      <th scope="col">Telephone</th> 
	      <th scope="col">Pseudo</th>  
	    </tr>
	  </thead>
	  <tbody id="body_tableau_liste_lecteurs">

	  </tbody>
	</table>

	<div class="modal fade" id="modal_nouveau_lecteur" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Ajout nouveau lecteur</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	      <div class="modal-body">
	       	<form method="post">
				  <div class="mb-3">
				    <label for="pseudolecteur" class="form-label">Nom</label>
				    <input type="text" class="form-control" id="pseudolecteur" name="pseudolecteur" placeholder="Entrez le pseudo du lecteur" >
				  </div>
				  <div class="modal-footer">
	        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
	        <button type="submit" class="btn btn-primary">Ajouter</button>
	      </div>
			</form>
	      </div>
	      
	    </div>
	  </div>
	</div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" ></script>
</body>
</html>