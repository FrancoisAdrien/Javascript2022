<?php

	include('connexion_bd.php');

	if(isset($_POST['idutilisateur']))
		{		
			$idutilisateur = $_POST['idutilisateur'];


	 //     $liste_formulaire_en_lecture_bd = $connexion_bd_projetjs->query('SELECT * FROM lecteur_formulaire lf inner join formulaire f  on (lf.idformulaire=f.id) WHERE  lf.idlecteur =  '.$idutilisateur.'  ');

			$liste_formulaire_en_lecture_bd = $connexion_bd_projetjs->query('SELECT * FROM lecteur_formulaire lf inner join formulaire f  on (lf.idformulaire=f.id) inner join utilisateur u on (f.idutilisateur=u.id) WHERE  lf.idlecteur =  '.$idutilisateur.'  ');


	      $liste_formulaire_en_lecture = $liste_formulaire_en_lecture_bd->fetchAll();

		}

?>


 <?php 	

 	$compteur=0;

  	foreach($liste_formulaire_en_lecture as $formulaire)
	  	{  	 
	  		$compteur++;
  	?>
    <tr>
      <th scope="row"><?php echo $compteur;?></th>
      <td><?php echo $formulaire['code'];?></td>
      <td><?php echo $formulaire['titre'];?></td>
      <td><?php echo $formulaire['datedebut'];?></td>
      <td><?php echo $formulaire['datelimite'];?></td>
      <td><?php echo $formulaire['pseudo'];?></td>
      <td>
      	<a class="btn btn-success" target="_blank" href="generation_reponse_formulaire_pdf.php?id=<?php echo $formulaire['idformulaire'];?>" role="button">Réponses</a>
      </td>
    </tr>
    <?php 
		} 
	?>
