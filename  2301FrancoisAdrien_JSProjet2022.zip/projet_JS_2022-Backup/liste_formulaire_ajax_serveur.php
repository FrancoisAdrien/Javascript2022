<?php

      include('connexion_bd.php');

      	if(isset($_POST['id']))
      	{
      		$id=$_POST['id'];
      	}

      $liste_formulaire_bd = $connexion_bd_projetjs->query('SELECT * FROM formulaire WHERE idutilisateur = "'.$id.'"'); // where id = valeur de l'utilisateur

      $liste_formulaire = $liste_formulaire_bd->fetchAll();
 

    ?>

     <?php 
     
     $compteur=0;
  	foreach($liste_formulaire as $formulaire)
	  	{  	 
	  		$compteur++;
  	?>
    <tr>
      <th scope="row"><?php echo $compteur;?></th>
      <td><?php echo $formulaire['code'];?></td>
      <td><?php echo $formulaire['titre'];?></td>
       <td><?php echo $formulaire['datedebut'];?></td>
      <td><?php echo $formulaire['datelimite'];?></td>
      <td>
      	<a class="btn btn-dark" href="modifier_champs_formulaire.php?id=<?php echo $formulaire['id'];?>" role="button">Champs</a>
   		<a class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modal_modifier_titre_formulaire"  data-id="<?php echo $formulaire['id'];?>"role="button">Modifier</a>

      	<a class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal_supprimer_formulaire" data-id="<?php echo $formulaire['id'];?>" href="" role="button">Supprimer</a>

      	<a class="btn btn-info" id="button_lecteur_formulaire" href="liste_lecteurs_formulaire.php?id=<?php echo $formulaire['id'];?>" role="button">Lecteurs</a>
      	<a class="btn btn-secondary" id="button_repondant_formulaire" href="liste_repondants_formulaire.php?id=<?php echo $formulaire['id'];?>" role="button">Répondants</a>
      	<!--<button class="btn btn-success" id="button_reponses_formulaire" name="<?php echo $formulaire['id'];?>" role="button">Réponses</button> -->
      	<a class="btn btn-success" target="_blank" href="generation_reponse_formulaire_pdf.php?id=<?php echo $formulaire['id'];?>" role="button">Réponses</a>

      </td>
    </tr>
    <?php 
		} 
	?>
	<!-- Button trigger modal -->


<!-- Modal -->
