<?php

      include('connexion_bd.php');

      	if(isset($_POST['id']))
      	{
      		$idformulaire=$_POST['id'];
      	}

      $formulaire_bd = $connexion_bd_projetjs->query('SELECT * FROM formulaire WHERE id = "'.$idformulaire.'"'); 

      $formulaire = $formulaire_bd->fetch();

      $champ_bd = $connexion_bd_projetjs->query('SELECT * FROM champ WHERE idformulaire = \'' . $idformulaire . '\' '); 

      $liste_champs = $champ_bd->fetchALL();


      if(isset($_POST['idrepondant']))
      {
      		$idrepondant=$_POST['idrepondant'];


      		$requete_reponse_bd = $connexion_bd_projetjs->query('SELECT * FROM reponse WHERE idrepondant = \'' . $idrepondant . '\'  AND idformulaire = \'' . $idformulaire . '\' ');

      		$reponse_bd = $requete_reponse_bd->fetch();

      		if($reponse_bd['json_reponse'] != null)
      		{
      			$json_reponse=json_decode($reponse_bd['json_reponse']);
      		}
      		else{
      			$json_reponse='{}';
      		}     		
     }

?>

      <?php 
      foreach($liste_champs as $champ)
	  	{  	 
		  	?>	
		  	<?php 
		  		if($champ['type'] == 'champ_courte'){
		  			$titre_champ = $champ['titre_champ'];
		  			$json_reponse == '{}' ? $reponse='' : $reponse =$json_reponse->$titre_champ;
		  	?>	   
			     <div class="mb-3">
					<label for="exampleFormControlTextarea1" id="label_champ_courte"class="form-label"><?php echo $champ['titre_champ'];?>
					</label>
					<input type ="text" class="form-control" id="<?php echo $champ['titre_champ'];?>" name="<?php echo $champ['titre_champ'];?>" placeholder="<?php echo $champ['description_champ'];?>"  value="<?php echo $reponse;?>">
					
				</div>
			<?php 
		  		}
		  		else if($champ['type'] == 'champ_longue'){
		  			$titre_champ = $champ['titre_champ'];
		  			$json_reponse == '{}' ? $reponse='' : $reponse =$json_reponse->$titre_champ;
		  	?>

		  		 <div class="mb-3">
					<label for="exampleFormControlTextarea1" id="label_champ_longue"class="form-label"><?php echo $champ['titre_champ'];?>
					</label>
					<textarea type ="text" class="form-control" id="<?php echo $champ['titre_champ'];?>" name="<?php echo $champ['titre_champ'];?>" > <?php echo$json_reponse->$titre_champ;?> </textarea>				
				</div>

	  		<?php 
		  		}
		  		else if($champ['type'] == 'champ_select'){
		  			$titre_champ = $champ['titre_champ'];
		  	?>
		  		<div class="mb-3">
			  		<label for="formGroupExampleInput" id="label_champ_select"class="form-label"><?php echo $champ['titre_champ'];?> </label>
			  		<div class="mb-3">
			  			<select class="form-select" name ="<?php echo $champ['titre_champ'];?>" aria-label="Default select example" id="form_select">
				
			  		<?php
			  			$idchamp=$champ['id'];
			  			$option_champ_bd = $connexion_bd_projetjs->query('SELECT * FROM option_champ WHERE idchamp = \'' . $idchamp . '\' '); 
	      				$liste_options = $option_champ_bd->fetchALL();

	      				 foreach($liste_options as $option)
	      				 {
	      				 	$titre_option_champ = $option['titre_option'];
	      				 	$json_reponse == '{}' ? $reponse='' : $reponse =$json_reponse->$titre_champ;
	      			?> 				
	      				<option value="1" id="option_nouveau_select" <?php echo(($titre_option_champ == $reponse)? 'selected' : ''); ?> ><?php echo  $option['titre_option'];?></option>

	      		<!--		<option value="1" id="option_nouveau_select" <?php echo (($titre_option_champ == $json_reponse->$titre_champ)? 'selected' : ''); ?> ><?php echo  $option['titre_option'];?></option> -->

	      			<?php	  
	      				 }		
      				?>
      					</select>
      					
      				</div>
			  	</div>

		  	<?php
		  		}
		  		else if($champ['type'] == 'champ_check'){
		  		$titre_champ = $champ['titre_champ'];	  						
		  	?>
		  		<div class="mb-3 groupe_champ_check">
			  		<label for="formGroupExampleInput" id="label_champ_check"class="form-label"><?php echo $champ['titre_champ'];?></label>
			  		<div class="mb-3">
			  		<?php
			  			$idchamp=$champ['id'];
			  			$option_champ_bd = $connexion_bd_projetjs->query('SELECT * FROM option_champ WHERE idchamp = \'' . $idchamp . '\' '); 
	      				$liste_options = $option_champ_bd->fetchALL();

	      				 foreach($liste_options as $option)
	      				 {
	      				 	$titre_option_check=$option['titre_option'];
	      				 	$array_liste_options =($json_reponse !='{}') ? explode(',',$json_reponse->$titre_champ)	: array();

	      			?> 				
	      				<input class="form-check-input" type="checkbox" value="" name="<?php echo $option['titre_option'];?>" id="<?php echo $option['titre_option'];?>" <?php echo(in_array($titre_option_check, $array_liste_options))? 'checked' : ''; ?> >
						<label class="form-check-label" for="flexCheckDefault"id="nouveau_label_check"><?php echo $option['titre_option'];?></label>
						

	      			<?php	  
	      				 }		
      				?>
      				</div>
			  	</div>
		  	
		  	<?php 
		  		}
		  		else if($champ['type'] == 'champ_radio'){
		  			$titre_champ = $champ['titre_champ'];
		  	?>
		  		<div class="mb-3 groupe_champ_radio" >
			  		<label for="formGroupExampleInput" id="label_champ_radio"class="form-label"><?php echo $champ['titre_champ'];?></label>
			  		<div class="mb-3">

			  		<?php
			  			$idchamp=$champ['id'];
			  			$option_champ_bd = $connexion_bd_projetjs->query('SELECT * FROM option_champ WHERE idchamp = \'' . $idchamp . '\' '); 
	      				$liste_options = $option_champ_bd->fetchALL();

	      				 foreach($liste_options as $option)
	      				 {
      				 		$titre_option_radio = $option['titre_option'];
      				 		$json_reponse == '{}' ? $reponse='' : $reponse =$json_reponse->$titre_champ;

	      			?> 				
	      				<input class="form-check-input" type="radio" name="<?php echo $champ['titre_champ'];?>" value="<?php echo $option['titre_option'];?>" id="<?php echo $option['titre_option'];?>" <?php echo(($titre_option_radio == $reponse)? 'checked' : ''); ?>>
  						<label class="form-check-label" for="flexRadioDefault1" id="nouveau_label_radio"><?php echo $option['titre_option'];?></label>
  						

	      			<?php	  
	      				 }		
      				?>
      				</div>
			  	</div>
		  	<?php 
		  		}
		  	?>

		<?php    
		} 

		?>

		<?php 

			if(date("Y-m-d") >= $formulaire['datedebut'] &&  date("Y-m-d") <= $formulaire['datelimite'])
			{

			?>
		<a class="btn btn-success" data-bs-toggle="modal" id="sauvegarder_json"data-bs-target="#modal_sauvegarder_formulaire" data-id="" href="" role="button">Sauvegarder</a>

		<?php 
 		}
 		else if (date("Y-m-d") > $formulaire['datelimite'])
 		{
 		?>	
 			<div class="alert alert-danger" role="alert">
 				La période de réponse au formulaire est dépassée !
			</div>	
		<?php 
 		}else if (date("Y-m-d") < $formulaire['datedebut'])
 		{
 		?>	
 			<div class="alert alert-danger" role="alert">
 				La période de réponse au formulaire n'est pas encore arrivée !
			</div>	
		<?php 
 		}
   	?>