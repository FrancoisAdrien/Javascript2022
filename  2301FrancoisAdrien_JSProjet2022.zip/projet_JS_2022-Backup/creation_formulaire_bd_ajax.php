<?php

	include('connexion_bd.php');

	if(isset($_POST['code']) && isset($_POST['titre'])  && isset($_POST['datedebut']) && isset($_POST['datelimite']) && isset($_POST['idutilisateur']))
		{		
			$code = $_POST['code'];
			$titre = $_POST['titre'];
			$datedebut = $_POST['datedebut'];
			$datelimite = $_POST['datelimite'];
			$idutilisateur = $_POST['idutilisateur'];

			$insertion_utilisateur =$connexion_bd_projetjs->prepare('INSERT INTO formulaire (code,titre,datedebut,datelimite,idutilisateur) VALUES (:code,:titre,:datedebut,:datelimite,:idutilisateur)'); 

			$insertion_utilisateur->execute(array(
				'code' => $code,
				'titre' => $titre,
				'datedebut' => $datedebut,
				'datelimite' => $datelimite,
				'idutilisateur' => $idutilisateur
			));
		}
?>