<!DOCTYPE html>
<html>
<head>
	<title>Formulaire de Test</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="produits.css">
</head>
<body>
	<form>
	  <div class="mb-3">
	    <label for="inputEmail" class="form-label">Adresse E-mail</label>
	    <input type="email" class="form-control" id="inputEmail" aria-describedby="emailHelp">
	  </div>
	  <div class="mb-3">
	    <label for="inputPassword" class="form-label">Mot de passe</label>
	    <input type="password" class="form-control" id="inputPassword">
	  </div>
	  <div class="mb-3">
	    <label for="inputAge" class="form-label">Age</label>
	    <input type="number" class="form-control" id="inputAge" aria-describedby="emailHelp">
	  </div>
	  <button type="submit" class="btn btn-primary">Envoyer</button>
	</form>
</body>
</html>