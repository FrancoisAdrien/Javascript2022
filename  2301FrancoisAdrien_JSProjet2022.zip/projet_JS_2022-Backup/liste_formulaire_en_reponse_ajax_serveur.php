<?php

	include('connexion_bd.php');

	if(isset($_POST['idutilisateur']))
		{		
			$idutilisateur = $_POST['idutilisateur'];

	 //     $liste_formulaire_en_lecture_bd = $connexion_bd_projetjs->query('SELECT * FROM lecteur_formulaire lf inner join formulaire f  on (lf.idformulaire=f.id) WHERE  lf.idlecteur =  '.$idutilisateur.'  ');

			$liste_formulaire_en_reponse_bd = $connexion_bd_projetjs->query('
        SELECT f.id as idformulaire,f.titre as titreformulaire,f.code as codeformulaire,f.datedebut as datedebut ,f.datelimite as datelimite, u.pseudo as pseudo
        FROM repondant_formulaire rf inner join formulaire f  on (rf.idformulaire=f.id) inner join utilisateur u on (f.idutilisateur=u.id) WHERE  rf.idrepondant =  '.$idutilisateur.'  ');


	      $liste_formulaire_en_reponse = $liste_formulaire_en_reponse_bd->fetchAll();

		}

?>


 <?php 

  	foreach($liste_formulaire_en_reponse as $formulaire)
	  	{  	 
  	?>
    <tr>
      <th scope="row"><?php echo $formulaire['idformulaire'];?></th>
      <td><?php echo $formulaire['codeformulaire'];?></td>
      <td><?php echo $formulaire['titreformulaire'];?></td>
      <td><?php echo $formulaire['datedebut'];?></td>
      <td><?php echo $formulaire['datelimite'];?></td>
      <td><?php echo $formulaire['pseudo'];?></td>
      <td>
      	<a class="btn btn-success" id="btn_repondre_formulaire" href="repondre_formulaire.php?id=<?php echo $formulaire['idformulaire'];?>" role="button">Répondre au formulaire</a>
      </td>
    </tr>
    <?php 
		} 
	?>
