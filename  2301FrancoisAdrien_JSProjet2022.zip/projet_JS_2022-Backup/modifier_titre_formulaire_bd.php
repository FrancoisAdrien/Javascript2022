<?php

	include('connexion_bd.php');

	if(isset($_POST['idformulaire']) && isset($_POST['titre_formulaire']) && isset($_POST['code_formulaire']))
		{
			$idformulaire = $_POST['idformulaire'];
			$titre_formulaire = $_POST['titre_formulaire'];
			$code_formulaire = $_POST['code_formulaire'];

			
		$insertion_utilisateur_prepare =$connexion_bd_projetjs->prepare('UPDATE formulaire SET titre=:titre,code=:code WHERE id = \'' . $idformulaire . '\' ');

		$insertion_utilisateur_prepare->execute(array(
			'titre' => $titre_formulaire,
			'code' => $code_formulaire,
		));
		}
?>