<?php

	include('connexion_bd.php');

	if(isset($_POST['nom']) && isset($_POST['prenom']) && isset($_POST['email']) && isset($_POST['telephone']) && isset($_POST['pseudo']) && isset($_POST['mdp']) && isset($_POST['etat']))
		{		
			$nom = $_POST['nom'];
			$prenom = $_POST['prenom'];
			$email = $_POST['email'];
			$telephone = $_POST['telephone'];
			$pseudo = $_POST['pseudo'];
			$mdp= $_POST['mdp'];
			$etat=$_POST['etat'];
			
			$insertion_utilisateur =$connexion_bd_projetjs->prepare('INSERT INTO utilisateur (nom,prenom,email,telephone,pseudo,mdp,etat) VALUES (:nom,:prenom,:email,:telephone,:pseudo,:mdp,:etat)'); 

			$insertion_utilisateur->execute(array(
				'nom' => $nom,
				'prenom' => $prenom,
				'email' => $email,
				'telephone' => $telephone,
				'pseudo' => $pseudo,
				'mdp' => $mdp,
				'etat' => $etat
			));

		}
		$requete = $connexion_bd_projetjs->query("SELECT id FROM utilisateur WHERE pseudo = '".$pseudo."' AND mdp= '".$mdp."'");
		$id_utilisateur = $requete->fetch();

		echo $id_utilisateur['id'];	
?>