<?php

	include('connexion_bd.php');

	if(isset($_POST['titre']) && isset($_POST['description']) && isset($_POST['type']) && isset($_POST['checked']) && isset($_POST['idformulaire']))
		{ 		
			$titre_champ = $_POST['titre'];
			$description_champ = $_POST['description'];
			$type = $_POST['type'];
			$idformulaire = $_POST['idformulaire'];
			$checked = $_POST['checked'];
			

			$insertion_champ =$connexion_bd_projetjs->prepare('INSERT INTO champ (titre_champ,description_champ,type,checked,idformulaire) VALUES (:titre_champ,:description_champ,:type,:checked,:idformulaire)'); 

			$insertion_champ->execute(array(
				'titre_champ' => $titre_champ,
				'description_champ' => $description_champ,
				'type' => $type,
				'checked' => $checked,
				'idformulaire' => $idformulaire,
			));
		}
		
		echo $_POST['checked'];
?>