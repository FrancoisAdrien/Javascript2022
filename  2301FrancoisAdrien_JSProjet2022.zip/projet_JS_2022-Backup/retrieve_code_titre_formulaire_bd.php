<?php

      include('connexion_bd.php');

      	if(isset($_POST['id']))
      	{
      		$id=$_POST['id'];
      	}

      $formulaire_bd = $connexion_bd_projetjs->query('SELECT * FROM formulaire WHERE id = \'' . $id . '\' '); // where id = valeur de l'utilisateur

      $formulaire = $formulaire_bd->fetch();

      echo $formulaire['titre']."   ---   ".$formulaire['code'];
 

    ?>