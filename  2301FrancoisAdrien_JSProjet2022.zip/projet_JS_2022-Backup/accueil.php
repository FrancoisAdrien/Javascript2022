<!DOCTYPE html>
<html>
<head>
	<title>Accueil</title>
	<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" >
	<link rel="stylesheet" type="text/css" href="projetjs.css">
		
	
	<script type="text/javascript" src="jquery-3.6.0.min.js"></script>

	<script type="text/javascript"> </script>
	<script type="text/javascript">
	</script>
	<script type="text/javascript">
    
    $(document).ready(function( ) {								

      $.ajax({
          type:"post",
          url:"liste_formulaire_ajax_serveur.php",
          data: "id="+sessionStorage.getItem('id_utilisateur'), 
          success : function(data){
            $('#body_tableau_liste_formulaire').html(data);
          }

      });

		$('#modal_supprimer_formulaire').on('show.bs.modal', function (e) {

		    var idformulaire = $(e.relatedTarget).attr('data-id');
		    $(this).find('.idformulaire').text(idformulaire);

		    $('#btn_supprimer_formulaire').click(function(){
		    	console.log(idformulaire);
		    	$.ajax({
					type:"post",
					url:"supprimer_formulaire_bd.php",
					data:"idformulaire="+idformulaire,
					success : function(data){				 
						//alert(data);			
					}		
				});

		    });
	    
		})

		$('#modal_modifier_titre_formulaire').on('show.bs.modal', function (e) {

		    var idform = $(e.relatedTarget).attr('data-id');
		    $(this).find('.idform').text(idform);
	
		   	console.log(titre_formulaire, code_formulaire);

		    $('#btn_modifier_titre_formulaire').click(function(){

		    	var titre_formulaire=$('#titre_formulaire').val();
		   		var code_formulaire=$('#code_formulaire').val();

		    	$.ajax({
					type:"post",
					url:"modifier_titre_formulaire_bd.php",
					data:"idformulaire="+idform + "&titre_formulaire="+titre_formulaire + "&code_formulaire="+code_formulaire,
					success : function(data){				 
						//alert(data);			
					}		
				});

		    });
	     });

		$('#modal_ajouter_formulaire').on('show.bs.modal', function (e) {
	
		    $('#btn_ajouter_formulaire').click(function(){

		    	var titre_formulaire=$('#titre_formulaire_ajout').val();
		   		var code_formulaire=$('#code_formulaire_ajout').val();
		   		var date_debut_ajout=$('#date_debut_ajout').val();
		   		var date_limite_ajout=$('#date_limite_ajout').val();

		    	$.ajax({
					type:"post",
					url:"creation_formulaire_bd_ajax.php",
					data:"code="+code_formulaire + "&titre="+titre_formulaire + "&datedebut="+date_debut_ajout + "&datelimite="+date_limite_ajout + "&idutilisateur="+sessionStorage.getItem('id_utilisateur'),
					success : function(data){				 
									
					}		
				});

		    });
	     });

    });


  </script> 
</head>
<body>

<nav class="navbar navbar-expand-xxl navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="accueil.php">Projet Javascript 2022</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="accueil.php">Édition formulaire</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="lecteur_formulaire.php">Lecture formulaire</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="repondant_formulaire.php">Réponse formulaire</a>
        </li>
      </ul>
    </div>
   		 <ul class="navbar-nav ml-auto" id="navbarNav">
   		 	<script type="text/javascript">						
   		 		var idutilisateur = sessionStorage.getItem('id_utilisateur');

   		 		if(idutilisateur)
   		 		{/*
   		 			$('#navbarNav').html('<li class="nav-item"><a class="nav-link" href="deconnexion_utilisateur.php">Déconnexion</a></li>');  */
   		 			$('.nonconnecte').attr('hidden','true');		 			
   		 		}else{/*
   		 			$('#navbarNav').html('<li class="nav-item"><a class="nav-link" href="inscription_utilisateur.php">Inscription</a>    </li><li class="nav-item"><a class="nav-link" href="connexion_utilisateur.php">Connexion</a></li>');*/
   		 			$('.connecte').attr('hidden','true');	
   		 		}

   		 	</script>
          <!--  <li class="nav-item nonconnecte" >
	          <a class="nav-link" href="inscription_utilisateur.php">Inscription</a>
	        </li> 
	        <li class="nav-item nonconnecte">
	          <a class="nav-link" href="connexion_utilisateur.php">Connexion</a>
	        </li>-->
	        <li class="nav-item connecte">
	          <a class="nav-link" href="deconnexion_utilisateur.php">Déconnexion</a>
	        </li> 
        </ul>
  	</div>
</nav>
	<br/>
	<a class="btn btn-success" data-bs-toggle="modal" data-bs-target="#modal_ajouter_formulaire" href="" role="button">+ Nouveau formulaire</a>
	<br/>
	<br/>
	<h1>Liste des formulaires de l'utilisateur <script type="text/javascript"> document.write(sessionStorage.getItem('id_utilisateur')); </script> </h1>
	<br/>
<table class="table" table-striped">
  <thead>
    <tr> 
    	<th scope="col">#</th>
      <th scope="col">Code</th>
      <th scope="col">Titre</th>
      <th scope="col">Date debut</th>  
      <th scope="col">Date limite</th> 
      <th scope="col">Actions</th>
    </tr>
  </thead>
  <tbody id="body_tableau_liste_formulaire">

  </tbody>
</table>

	<div class="modal fade" id="modal_supprimer_formulaire" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Supprimer un formulaire ?</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	     	<form method="post">
	      		<div class="modal-body">       
					 <p> Êtes vous sûr de vouloir supprimer le formulaire n°<span class="idformulaire"></span> ?</p>
				  <div class="modal-footer">
			        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
			        <button type="submit" id="btn_supprimer_formulaire" class="btn btn-danger">Supprimer</button>
			      </div>
			
	      		</div>
	      </form>
	    </div>
	  </div>
	</div>

	<div class="modal fade" id="modal_modifier_titre_formulaire" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Modifier le formulaire n°<span class="idform"></span> ?</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	     	<form method="post">
	      		<div class="modal-body">
	      			<div class="mb-3">
					    <label for="titre_formulaire" class="form-label">Titre du formulaire</label>
					    <input type="text" class="form-control" id="titre_formulaire" name="titre_formulaire">
					  </div>
					  <div class="mb-3">
					    <label for="code_formulaire" class="form-label">Code</label>
					    <input type="text" class="form-control" id="code_formulaire" name="code_formulaire" >
					  </div>       
				  <div class="modal-footer">
			        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
			        <button type="submit" id="btn_modifier_titre_formulaire" class="btn btn-danger">Appliquer les changements</button>
			      </div>
			
	      		</div>
	      </form>
	    </div>
	  </div>
	</div>
	<div class="modal fade" id="modal_ajouter_formulaire" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
	  <div class="modal-dialog">
	    <div class="modal-content">
	      <div class="modal-header">
	        <h5 class="modal-title" id="exampleModalLabel">Création nouveau formulaire</h5>
	        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
	      </div>
	     	<form method="post">
	      		<div class="modal-body">
	      			<div class="mb-3">
					    <label for="titre_formulaire_ajout" class="form-label">Titre du formulaire</label>
					    <input type="text" class="form-control" id="titre_formulaire_ajout" name="titre_formulaire_ajout">
					  </div>
					  <div class="mb-3">
					    <label for="code_formulaire_ajout" class="form-label">Code</label>
					    <input type="text" class="form-control" id="code_formulaire_ajout" name="code_formulaire_ajout" >
					  </div>
					  <div class="mb-3">
					    <label for="date_debut_ajout" class="form-label">Entrez la date de debut</label>
					    <input type="date" class="form-control" id="date_debut_ajout" name="date_debut_ajout" >
					  </div>
					   <div class="mb-3">
					    <label for="date_limite_ajout" class="form-label">Entrez la date limite</label>
					    <input type="date" class="form-control" id="date_limite_ajout" name="date_limite_ajout" >
					  </div>       
				  <div class="modal-footer">
			        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fermer</button>
			        <button type="submit" id="btn_ajouter_formulaire" class="btn btn-success">+ Ajouter formulaire</button>
			      </div>
			
	      		</div>
	      </form>
	    </div>
	  </div>
	</div>


	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" ></script>
</body>
</html>