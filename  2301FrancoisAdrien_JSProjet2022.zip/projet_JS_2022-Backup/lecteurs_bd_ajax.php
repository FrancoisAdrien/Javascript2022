<?php

	include('connexion_bd.php');

	if(isset($_POST['pseudolecteur']))
		{		
			$pseudolecteur = $_POST['pseudolecteur'];


	      $pseudolecteur_bd = $connexion_bd_projetjs->query('SELECT * FROM utilisateur WHERE pseudo = \'' . $pseudolecteur . '\' '); 

	      $lecteur = $pseudolecteur_bd->fetch();

	      		
	      if(isset($_POST['idformulaire']))
	      {

	      	$idformulaire = $_POST['idformulaire'];

	      	$insertion_lecteur_formulaire =$connexion_bd_projetjs->prepare('INSERT INTO lecteur_formulaire (idformulaire,idlecteur) VALUES (:idformulaire,:idlecteur)'); 

			$insertion_lecteur_formulaire->execute(array(

				'idformulaire' => $idformulaire,
				'idlecteur' => $lecteur['id'],
			));

	      }

		}


?>

<tr>
      <th scope="row"><?php echo $lecteur['id'];?></th>
      <td><?php echo $lecteur['nom'];?></td>
      <td><?php echo $lecteur['prenom'];?></td>
      <td><?php echo $lecteur['email'];?></td>
      <td><?php echo $lecteur['telephone'];?></td>
      <td><?php echo $lecteur['pseudo'];?></td>
      <td>
      <!--	<a class="btn btn-danger" id="boutton_supprimer_formulaire" href="supprimer_utilisateur.php?id=<?php echo $lecteur['id'];?>" role="button">Supprimer</a> -->
      <a class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modal_supprimer_lecteur" data-id="<?php echo $lecteur['id'];?>" href="" role="button">Supprimer</a>
      </td>
    </tr>